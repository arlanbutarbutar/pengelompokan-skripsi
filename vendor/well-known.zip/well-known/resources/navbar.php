<header class="header_section">
  <div class="container-fluid">
    <nav class="navbar navbar-expand-lg custom_nav-container">
      <a class="navbar-brand" href="./">
        <img src="assets/images/logo.png" style="width: 50px;" alt="" />
      </a>

      <div class="navbar-collapse" id="">
        <div class="custom_menu-btn">
          <button onclick="openNav()">
            <span class="s-1"> </span>
            <span class="s-2"> </span>
            <span class="s-3"> </span>
          </button>
        </div>
        <div id="myNav" class="overlay">
          <div class="overlay-content">
            <a href="./">Beranda</a>
            <a href="tentang">Tentang</a>
            <a href="auth/">Masuk</a>
          </div>
        </div>
      </div>
    </nav>
  </div>
</header>