<?php 
$conn=mysqli_connect("localhost","root","","jhdbfgel_100133");
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
