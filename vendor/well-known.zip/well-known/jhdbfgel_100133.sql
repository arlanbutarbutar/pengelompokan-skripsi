-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 09 Jul 2023 pada 15.26
-- Versi server: 10.4.25-MariaDB
-- Versi PHP: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jhdbfgel_100133`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `kelas`
--

CREATE TABLE `kelas` (
  `id_kelas` int(11) NOT NULL,
  `kelas` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `kelas`
--

INSERT INTO `kelas` (`id_kelas`, `kelas`) VALUES
(1, 'Soft Computing'),
(2, 'Mobile Computing');

-- --------------------------------------------------------

--
-- Struktur dari tabel `klasifikasi`
--

CREATE TABLE `klasifikasi` (
  `id_klasifikasi` int(11) NOT NULL,
  `id_testing` int(11) NOT NULL,
  `nilai_akhir` char(10) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `klasifikasi`
--

INSERT INTO `klasifikasi` (`id_klasifikasi`, `id_testing`, `nilai_akhir`, `created_at`, `updated_at`) VALUES
(360, 1, '0.18', '2023-06-20 07:39:22', '2023-06-20 07:39:22'),
(361, 2, '0.20249835', '2023-06-20 17:46:32', '2023-06-20 17:46:32'),
(367, 8, 'Mobile', '2023-07-06 08:32:15', '2023-07-06 08:32:15'),
(368, 9, 'Soft Compu', '2023-07-06 16:16:20', '2023-07-06 16:16:20'),
(374, 10, 'Mobile Com', '2023-07-07 08:28:35', '2023-07-07 08:28:35'),
(375, 11, 'Mobile Com', '2023-07-07 08:58:50', '2023-07-07 08:58:50'),
(376, 12, 'Mobile Com', '2023-07-07 13:34:41', '2023-07-07 13:34:41'),
(377, 13, 'Soft Compu', '2023-07-07 13:41:52', '2023-07-07 13:41:52'),
(378, 14, 'Soft Compu', '2023-07-09 10:56:51', '2023-07-09 10:56:51'),
(379, 15, 'Mobile Com', '2023-07-09 21:19:54', '2023-07-09 21:19:54');

-- --------------------------------------------------------

--
-- Struktur dari tabel `skripsi`
--

CREATE TABLE `skripsi` (
  `id_skripsi` int(11) NOT NULL,
  `nim` int(11) NOT NULL,
  `nama` varchar(75) NOT NULL,
  `judul` varchar(100) NOT NULL,
  `abstrak` text NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `jenis_perangkat` varchar(35) NOT NULL,
  `bahasa_pemrograman` varchar(20) NOT NULL,
  `pembimbing_satu` varchar(150) NOT NULL,
  `pembimbing_dua` varchar(150) NOT NULL,
  `penguji_satu` varchar(150) NOT NULL,
  `penguji_dua` varchar(150) NOT NULL,
  `tahun` year(4) NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `skripsi`
--

INSERT INTO `skripsi` (`id_skripsi`, `nim`, `nama`, `judul`, `abstrak`, `kategori`, `jenis_perangkat`, `bahasa_pemrograman`, `pembimbing_satu`, `pembimbing_dua`, `penguji_satu`, `penguji_dua`, `tahun`) VALUES
(15, 23108108, 'Ronald  Tualaka', 'Sistem pendukung keputusan penetuan siswa penerima beasiswa di sman 2 kupang', 'Kebutuhan terbsar teknologi informasi sekarang ini adalah kebutuhan akan sistem informasi. Berkembangnya teknologi informasi dan sistem informasi yang demikian pesat di era globalisasi sekarang ini telah membuat hampir semua aspek kehidupan tidak dapat terhindar dari penggunaan perangkat komputer. Penggunaan komputer yang umum adalah penggunaan komputer di suatu sekolah. Sekolah Menengah Atas Negeri (SMAN) 2 Kota Kupang merupakan sekolah negeri yang berada di bawah Dinas Pendidikan Kota Kupang. Seiring dengan banyaknya  siswa kurang mampu dan siswa berprestasi , maka diadakan beasiswa oleh Dinas Pendidikan. Pembagian beasiswa dilakukan untuk membantu siswa yang tidak mampu ataupun berprestasi selama menempuh studinya. Maka diperlukan sebuah sistem pendukung keputusan yang mampu memberikan prioritas yang sesuai dengan keinginan.\r\n Berdasarkan uraian d atas maka dibuat sebuah Sistem pendukung keputusan dalam menggunakan metode penelitian yang digunakan dalam penelitian itu adalah  metode waterfall dengan tahap permulaan digunakan beberapa teknik pengumpulan data seperti, observasi, wawancara dan studi literatur. Pengembangan sistem ini menggunakan metode SAW (Simple additive weighting) dan diimplementasikan menggunakan bahasa pemograman PHP ( Personal home page) dengan menggunakan database MySQL ( My Sructure Query Language ).\r\nHasil akhir penelitian ini adalah sistem pendukung keputusan  penerimaan beasiswa menggunakan metode SAW yang dibangun mampu memberika prioritas bagi pegawai tata usaha dalam pengambilan keputusan penerimaan beasiswa. \r\n', 'Sistem Informasi', 'Software', 'Java', 'Paulus Irsan Dardana, S.T., M.T', 'Yulianti P. Bria Seran, S.T., MM', 'Donatus J. Manehat, S.Si, M.Kom', 'Natalia M.R. Mamulak, S.T., MM', 2016),
(16, 23109012, 'Ambrosius A. oro gare', 'Sistem pendukung keputusan untuk proses kenaikan jabatan pada kantor dinas pendidikan pemuda dan ola', 'Kenaikan jabatan merupakan suatu faktor yang sangat penting bagi perencanaan karir pegawai dan juga untuk meremajakan suatu posisi jabatan agar diduduki oleh seseorang yang mempunyai kriteria-kriteria yang cocok. Kenaikan jabatan dan perencanaan karir pada Dinas Pendidikan Pemuda dan Olahraga tidak mempertimbangkan faktor pengetahuan, ketrampilan, sikap dan perilaku yang dimiliki pegawai. \r\nSistem pendukung keputusan menjadi suatu alternatif yang dipakai untuk mendukung pengambilan keputusan proses kenaikan jabatan pada dinas PPO kabupaten sikks dengan menggunakan metode pencocokan profile \r\n', 'Analisis Data', 'Software', 'Python', 'Paulina Aliandu, ST,M.Cs', 'Natalia M. Mamulak, ST.MM', 'Sisilia D.B Mau,S.Kom,MT', 'Frengky Teddy, ST,MT', 2016),
(17, 23111036, 'Juaquim da costa pinto', 'Perancangan implementasi website tim penggerak pemberdayaan dan kesejahtraann keluarga kota kupang', 'Tim pengerak pemberdayaan dan kesejahtraan keluarga kota kupang (tppkk) merupakan mitra kerja pemerintah kota kupang berfungsi sebagai fasilitator, perencana, pelaksana, pengendali dan penggerak demi terlaksananya program kerja PPKK Kota Kupang. Salah satu cara yang sering digunakanuntuk memberikan informasi kepada masyarakat tentang jadwal kegiatab TPPKK Kota Kupang yaitu dengan cara memberikan surat yang diantar pegawai langsung ke masyarakat di RT, RW maupun di kelurahan. Kendala yang dirasakan oleh masyarakat saat ini adalah sulitnya untuk mendapatkan informasi mengenai TPPKK, karena surat yang diantar pegawai TPPKK sering tidak sampai tujuan. Oleh karena itu dipelukan sebuah sistem informasi untuk mengatasi permasalahan di atas, maka akan dirancang bangun suatu â€œperancangan dan impllementasi website tim penggerak pemberdayaan dan kesejahteraan keluarga kota kupangâ€. Metode yang digunakan untuk perancangan sistem ini yaitu Unified process (UP) serta bahasa pemograman yang digunakan yaitu php dan menggunakan mysql sebagai databasenya. Hasil yang diharapkan dari sistem ini adalah untuk meningkatkan pelayanan dalam memberikan informasi mengenai data-data jadwal kegiatan bagi masyarakat dan pihak-pihak yang membutuhkan informasi dari TPPKK.', 'Analisis Data', 'Software', 'Python', 'Donatus J. Manehat, S.Si,.M.Kom', 'Frengky Teddy, ST,MT', 'Emanuel jando,S.Kom,MTI', 'Emerensiana Ngaga,ST.MT', 2016),
(18, 23111013, 'Adventrihard M.D ully weo', 'Pengenalan atribut pramuka serta sandi morse dan sandi semaphore berbasis multimedia pada siswa sd i', 'Permasalahan umu yang dihadapi oleh anggota pramuka saat ini yaitu kurang memahami arti dari masing-masing atribut serta sandi morse dan semaphore  yang ada dalam kegiatan kepramukaan. Untuk menjawab permasalahan yang sedang dihadapi saat ini maka perlu dikembangkan media pembelajaran â€Pengenalam Atribut Pramuka Serta Sandi Morse dan Sandi Semaphore Berbasis Multimedia Pada Siswa SD Inpres Oepoi Kota Kupangâ€ yang bertujuan agar setiap calon ataupun anggota pramuka dapat mengetahui arti dari setiap atribut-atribut serta sandi morse dan sandi semaphore yang ada pada kegiatan kepramukaan. Untuk menyelesaikan permasalahan yang ada maka motode yang digunakan dalam penelitian ini adalah metode pengembangan multimedia. Metode tersebut meliputi tahap concept (pengonsepan), design (perancangan), material collecting (pengumpulan bahan), assembly (pembuatan), testing (pengujian),  distribution (distribusi). Bahasa pemograman yang digunakan untuk mengembangkan multimedia pengenalan atribut ini menggunakan Macromedia Flash 8.\r\nHasi akhir yang diperoleh dari aplikasi ini yakni dapat membantu anggota pramuka siaga dalam mempelajari arti masing-masing atribut pramuka siaga serta sandi morse dan sandi semaphore dalam kegiatan kepramukaan. Hal ini dapat dilihat dari jawaban responden yang terdiri dari anggota pramuka siaga dan pembina pramuka terhadap pengujian aplikasi tersebut yaitu sebesar 84% responden memberikan penilaian â€œBaikâ€ terhadap aplikasi tersebut dan hanya 16%responden yang memberikan menilaian â€œKurangâ€ terhadap aplikasi tersebut, sehingga tidak menutup kemungkinan bahwa aplikasi ini dapat diterapkan dalam pembelajaran kepramukaan siaga. \r\n', 'Analisis Data', 'Software', 'Python', 'Yulianti P. Bria, ST.MT', 'Frengky Teddy, ST,MT', 'Paulina Aliandu, ST,M.Cs', 'Paulus irsan dardana ST,MT', 2016),
(19, 23109024, 'Blasius nuhan', 'Aplikasi pengolahan data pajak rumah makan pada dinas pendapatan pengelolohan keuangan dan aset daer', 'Pendapatan Asli Daerah (PAD) adalah pendapatan yang diperoleh daerah yang dipungut berdasarkan peraturan daerah sesuai dengan peraturan perundang-undangan. Pajak rumah merupakan salah satu PAD untuk daerah. Pehitungan pajak rumah makan merupakan salah satu fator yang sangat penting agar dapat tercapainya suatu perhitungan yang efisiensi dan efektif, sehingga memberikan informasi yang akurat kepada pemilik rumah makan. Perhitungan pajak rumah makan pada Dinas Pendapatan, Pengolahan Keuangan dan Aset Daerah Kabupaten Flores Timus belumoptimal karena masih menggunakan sistem manual sehingga berdampak pada keterlambatan pemberi informasu kepada pemilik rumah makan.\r\nSolusi dari permasalahan di atas adalah perlu dibangun sebuah aplikasi perhitungan pajak rumah makan untuk mendukung perhitungan pajak pada Dinas Pendapatan, Pengelolaan Keuangan dan Aset Daerah Kabupaten Flores Timur. Pengembangan perangkat lunak ini menggunakan model waterfall dengan bahasa pemogramannPHP dan Mysql sebagai database-nya.\r\nAplikasi perhitungan pajak rumah makan ini dapat menambah kinerja kerja yang lebih baik dan membantu memudahkan para pemilik rumah makan untuk memperolehh informasu besarnya pajak yang harus dibayar.\r\n', 'Analisis Data', 'Software', 'Python', 'Sisilia D. B. Mau, S.Kom.MT', 'Ign. Pricher A.N. Samane,S.Si.M.Eng', 'Donatus J. Manehat, S.Si, M.Kom', 'Paulina Aliandu, ST,M.Cs', 2016),
(20, 23109099, 'Paulus Aprimus nitbani', 'Rancang bangun pemilihan ketua himpunan mahasiswa program studi (hmps) berbasis web', 'Himpunan Mahasiswa Program Studi (HMPS) adalah organisasi kemanusiaan yang berfungsi merencanakan dan melaksanakan kegiatan ekstrakulikuler di tingkat jurusan. Oleh sebab itu semua program kerja yang ada didalamnya harus benar-benar terealisasi dan dikembangkan secara nyata dan mnyeuruh. Salayh satu program kerja HMPS adalah melakukan pemilihan kepengurusan HMPS. Dalam kurun waktu satu tahun selalu diadakan proses pemilihan untuk menggantikan ketua HMPS.  Kendala yang biasa dihadapi pada saat pemilihan adalah kurangnya partisipasi mahasiswa untuk datang mengikuti proses pemilihan Ketua HMPS sehingga sangat berpengaruh pada saat pemilihan. Berdasarkan kendala yang terjadi, maka dibuatlah aplikasi pemilihan berbasis Web yang bisa membantu mahasiswa yang tidak bisa berpartisipasi langsung untuk memilih ketua HMPS secara cepat, efektif dan efisien.\r\nAplikasi Pemilihan Ketua Himpunan Program Studi(HMPS) ini menggunakan tools  pemograman PHP dengan database MySQL dan metode waterfall.\r\nKeunggulan yang dimilik oleh sistem ini adalah pembauatan Aplikasi pemilihan ketua HMPS memberikan kemudahan bagi mahasiswa untuk memilih ketua HMPS, menambah minat mahasiswa untuk berpartisipasi dalam proses pemilihan ketua HMPS, menghemt biaya, mempermudah dan mempercepat proses pemilihan ketua HMPS.\r\n', 'Pengolahan Citra', 'Software', 'Python', 'Donatus J. Manehat, S.Si,.M.Kom', 'Ign. Pricher A.N. Samane,S.Si.M.Eng', 'Emiliana Meolbatak,ST.MT', 'Natalia M.R. Mamulak, S.T., MM', 2016),
(21, 23107093, 'Maria boli', 'Sistem informasi pengiriman barang pada pt dehla lontar exspres berbasis web', 'PT. delha Lontar Express Kupang merupakan perusahaan yang bergerak dibidang pengiriman barang melalui jalur darat, lau dan udara di seluruh Nusa Tenggara Timur (NTT). Saat ini proses pengiriman barang yang dilakukan sudah terkomputerisasi tetapi belum dapat menampilkan informasi secara detail yang dibutuhkan user seperti tidak adanya penentuan harga pengiriman barang dan juga tracking pengiriman barang. Demi meningkatkan kinerja perusahaan, PT. Delha Lontar Express membutuhkan aplikasi  sistem informasi berbasis web sehingga memudahkan pelanggan untuk melakukan pengiriman ataupun pengecekan status barang tanpa harus datang ke tempat pengiriman barang tersebut.\r\nDalam penyelesaian masalah ini metode yang digunakan adalah model Clasic Life Cycle(waterfall Model) dengan tahapan pengembangan antara lain, terdiri dari:tHp persiapan, tahap analisis, desain sistem, pengkodean (coding), tahap pengujian(testing). Sedangka pembuatan aplikasinya menggunakan database MySql dan bahasa pemograman PHP yang dapat membantu mengatasi kelemahan pada sistem.\r\nSistem akan menyimpan data pengiriman dan penerimaan barang, selain itu sistem ini akan dibuat dalam bentu website, sehingga data dan informasi yang dibutuhkan dapat diperoleh dengan cepat. Kemampuan dan kehandalan sistem ini, dapat diakses dengan mudah karena bersifat online.\r\n', 'Analisis Data', 'Software', 'PHP', 'Emiliana Meolbatak, ST.MT', 'Natalia M. Mamulak, ST.MM', 'Sisilia D.B Mau,S.Kom,MT', 'Emerensiana Ngaga,ST.MT', 2016),
(22, 23108077, 'Maritilogorium bani', 'Analisis Sentimen Produk Menggunakan Metode Naive Bayes', 'te', 'Analisis Data', 'Software', 'Python', 'Emiliana Meolbatak, ST.MT', 'Sislia Daeng Baka Mau,S.Kom.MT', 'Donatus J. Manehat, S.Si, M.Kom', 'Natalia M.R. Mamulak, S.T., MM', 2016),
(23, 23107081, 'Eusebio da conceicao de waynira', 'Pengembangan aplikasi surat keterangan catatan kepolisisan (skck) pada kantor kepolisian resort kupa', 'Perkembangan teknologi yang semakin maju pada saat ini, memacu manusia untuk berpikir lebih maju pula. Teknologi Informasi nerupakan teknologi yang dibangun dengan basis utama teknologi komputer. Untuk mempermudah kegiatan Polisi Resort Kupang Kota (POLRESTA) maka menerbitkan Surat Keterangan Catatan Kepolisian (SKCK) lebih cepat, serta dapat menghasilkan laporan yang valid dan terjamin. \r\nTujuan dari penelitian ini yaitu merancang dan membangun aplikasi penerbitan SKCK yang dapat meningkatkan kinerja para staf bagian pembuatan SKCK untuk melayani masyarakat yang ingin membuat SKCK, sehingga masyarakat pun akan merasa lebih mudah, nyaman dan dapat menghemat waktu. \r\nMetode yang digunakan dalam penelitian ini adalah linear sequential model, merupakan suatu metodologi pengembangan perangkat yang melakukan pendekatan secara sistemmatis dan urutan mulai dari level kebutuhan sistem ke tahap analisi, desain, coding, dan pengujian atau testing. \r\nHasil dari aplikasi yang dikembangkan ini menghasilkan laporan erupa SKCK dan register SKCK berdasarkan Bulan dan Tahun, serta mempermudah pihak operator pada Kepolisian Resort Kupang Kota khususnya pada bagian intelkam untuk membuat SKCK.\r\n', 'Analisis Data', 'Software', 'Python', 'Paulina Aliandu, ST,M.Cs', 'Ign. Pricher A.N. Samane,S.Si.M.Eng', 'Emanuel jando,S.Kom,MTI', 'Patrisius Batarius, ST.MT', 2016),
(24, 23112012, 'Yuventus Fransiskus leto', 'Aplikasi pengenalan fasilitas hotel pelangi kupang berbasis multimedia', 'Hotel pelangi merupakan salah satu hotel di kota kupang yang sangat ramai oleh banyaknya pengunjung, hal menjadi kendala bagi resepsionis yang hanya berjumlah 3 orang dan kurangnya alat bantu pengenalan informasi mengenai fasilitas-fasilitas hotel, sehingga resepaionis berperan secara langsung dalam mengantar pengunjung untuk melihat fasilitas hotel. Metode yang digunakan dalam penelitian ini adalah tahapan pengembangan multimedia dengan langkah-langkah berupa: concept, design, material collection, assembly, testing dan distribuion. Aplikasi yang dihasilkan bisa menjadi media promosi hotel dan alat bantu bagi resepsionis untuk mengenalkan fasilitas yang tersedia pada hotel sehingga menjadi lebih interaktif dan efiesien tanpa harus mengantar secara langsung untuk melihat fasilitas.', 'Aplikasi Mobile', 'Software', 'Python', 'Emiliana Meolbatak, ST.MT', 'Ign. Pricher A.N. Samane,S.Si.M.Eng', 'Patrisius Batarius, ST.MT', 'Emerensiana Ngaga,ST.MT', 2017),
(25, 23110102, 'San made suastawan', 'Aplikasi multimedia profil universitas katolik widya mandira kupang', 'Penyampaian informasi profil Universitas Katolik Widya mandira selama ini masih konvensional, kurang menarik minat masyarakat dan penyampaian informasi membutuhkan waktu yang lama, sehingga kurang efektif. Maka dibuatkanlah sebuah aplikasi multimedia profil Universitas Katolik Widya Mandira yang merupakan sebuah media penyimpanan informasi secara visual yangberada di dalamnya akan  berisi informasi mengenai visi dan misi dari universitas juga program studi yang ada pada universitas dengan animasi yang menarik sehingga menambah daya tarik calon mahasiswauntuk mendaftar pada Universitas Katolik Widya Mandira dan juga sebagai pelayanan ata jasa dari universitas katolik widya mandira. Multimedia yang dibuat menggunakan metodelogi pengembangan multimedia versi Sutopo-Luther yang meliputi: concept,design,material collection,assembly, testing, dan distribution. Hasil dari perancangan ini adalah menghasilkan sebuah aplikasi multimedia yang berisi animasi profil, fakultas dan program studi, unit-unit pembantu, dan informasi kontak universitas katolik widya mandira kupang. ', 'Analisis Data', 'Software', 'Python', 'Emiliana Meolbatak, ST.MT', 'Yulianti P. Bria Seran, S.T., MM', 'Patrisius Batarius, ST.MT', 'Sislia Daeng Baka Mau,S.Kom.MT', 2017),
(26, 23110138, 'Yohanes deberito bego', 'Media pembelajaran interaktif latihan soal ujian nasional mata pelajaran ipa untuk anak sekolah dasa', 'Latihan soal dan pebahasan materi ujian nasional penting dilaksanakan untuk membantu dan melatih belajar murid dalam mempersiapkan diri menghadapi un. Berdasarkan data yang diambil pada SDI Perumnas 2 kupang, terdapat beberapa masalah yang dialami murid, yaitu menurunya nilai UN murid pada mata pelajaran IPA dan meningkatnya rasa jenuh muris saat mengerjakan latihan soal UN. Dengan adanya multimedia pembelajaran interaktif latihan soal UN mampu mengatasi permasalahan belajar yang dialami murid SDI Perumnas 2 Kupang. Metode yang digunakan adalah model pengembangan meltimedia dengan menetapkan tahapan-tahapan sebagai berikut: analisis data, menentukan konsep desain, melakukan pengembangan, mengimplementasikan hasil desain, malakukan pengujian dan mengevaluasi hasil dengan tols yang diimplementasikan menggunakan aplikasi macromedia flash 8. Hasil dari penelitian ini adalah terciptanya suatu media pembelajaran latihan soal UN berbasi multimedia, yang didalamnya terdapat animasi, teks, dan gambar yang dapat meningkatkan pola pikir dari murid sehingga dapat nerpikir lebih kritis dan mandiri dalam mengikuti UN.', 'Aplikasi Mobile', 'Software', 'Java', 'Emiliana Meolbatak, ST.MT', 'Sislia Daeng Baka Mau,S.Kom.MT', 'Patrisius Batarius, ST.MT', 'Natalia M.R. Mamulak, S.T., MM', 2017),
(27, 23110097, 'Rinif viranda haumeny', 'Desain dan implementasi multimedia dalam pengenalan profesi pekerjaan pada taman kanak-kanak tunas h', 'Taman Kanak-Kanak Tunas Harapan Emaus Liliba Kupang merupakan Leembaga Yayasan Kristen. Kurikulum yang digunakan adalah kurikulum 2013 yakni penggunaan media belajar lebih dominan dalam proses pembelajaran salah satu faktor penyebab rendahnya hasil belajar diduga karena kurangnya penggunaan mendia dalam proses belajar mengajar dan keterbatasan media belajar yang hanya menggunakan poster, foto, dan gambar sehingga belajar siswa menjadi monoton dan kurang menarik. Oleh karena itu perlu dibuat desain dan implementasi multimedia pembelajaran interaktif pengenalan profesi pekerjaan. Metode perancangan yang digunakan adalah model pengembangan multimedia dengan menetapkan langkah-lanhkah yang harus diikuti untuk menghasilkan produk yang berupa rancangan aplikasi multimedia. Metode perancangan meliputi : konsep aplikasi, perancangan aplikasi, pengumpulan data, pembuatan, pengujian, dan distribusi. Aplikasi yang dibangun diimplementasikan menggunakan adobe flash cs6. Pembuatan media pembelajran yang lebih interaktif akan lebih menarik minat belajar siswa sehingga dapat meningkatkan pengetahuan siswa tentang pengenalan profesi pekerjaan serta fungsinya.', 'Aplikasi Mobile', 'Software', 'Java', 'Yulianti P. Bria, ST.MT', 'Ign. Pricher A.N. Samane,S.Si.M.Eng', 'Emiliana Meolbatak,ST.MT', 'Frengky Teddy, ST,MT', 2017),
(28, 23110101, 'Roy santos bana', 'Aplikasi Mobile Pemantauan Kesehatan Berbasis Internet of Things', 'tes', 'Aplikasi Mobile', 'Software', 'Java', 'Donatus J. Manehat, S.Si,.M.Kom', 'Emerensiana Ngaga,ST.MT', 'Patrisius Batarius, ST.MT', 'Natalia M.R. Mamulak, S.T., MM', 2017),
(29, 23113035, 'Radegunda bana', 'Rancang bangun sistem informasi pengolahan data penelitian dan pengabdian berbasis web', 'Lembaga penelitian dan pengabdian masyarakat (LPPM) Universitas Katolik Widya Mandira (UNWIRA) merupakan lembaga yang mengelola kegiatan penelitian dan pengabdian masyarakat byang dilakukan oleh civitas akademika Unwira. Pengolahan data dan penelitian masih dikelola secara manual dengan menggunakan aplikasi microsoft excel maupun word dan pengiriman dokumen dilakukan dengan cara dosen mengantar langsung ke LPPM. Hal ini kurang efektif karena memakan waktu dan tenaga. Untuk mengatasi persoalan diatas maka perlu dibangun suatu aplikasi berupa sistem informasi pengolahan data penelitian dan pengabdian pada LPPM Unwira berbasis wb sehingga dapat memudahkan proses pengelolaan daa oleh pegawai LPPM, memudahkan proses pengirim file proposal, laporan kemajuan, laporan akhir penelitian dan pengabdian oleh dosen Unwira ke Lppm, serta memudahkan reviewer memberikan penilaian dan tanggapan terhadap proposal dan laporan yang dikirim oleh para dosen. Sistem informasi ini dibangun menggunakan bahasa pemrogaraman PHP, dan database mysql, dengan metode waterfall. Hasil dari penelitian ini adalah sebuah sistem informasi pengelolaan data penelitian pada LPPM Unwira berbasis web, yang membantu para pengguna diantaranya pegawai lppm yang berperan sebagai admin, dosen, sebagai reviewer dalam mengelola data penelitian dan pengabdian secara cepat dan akurat.', 'Aplikasi Mobile', 'Software', 'Java', 'Yulianti P. Bria, ST.MT', 'Paskalis A. Nani, ST.MT', 'Emiliana Meolbatak,ST.MT', 'Frengky Teddy, ST,MT', 2017),
(30, 23106067, 'Yohanes stiven ndapa', 'Sistem informasi pendataan siswa sma katolik giovani kupang', 'SMA Katolik (SMAK) Giovani adalah salah satu sekokolah menegah atas terkemuka dikota kupang dimana perlu secara serius memperhatikan pengelolaan informasi. Salah satu aspek terpenting yang perlu dikelola adalah aspek pendataan siswa. Ada berbagai permasalahan terkait sistem yang berjalan di bagian tata usaha SMAK Giovani Kupang bahawa sistem pendataan siswa yang berjalan di SMAK Giovani sudah dilakukan secara terkomputernisasi akan tetapi masih sederhana. Pendataan siswa yang di lakukan di tata usaha belum menggunakan sebuah aplikasi bantu khusus untuk mengolah data siswa ada pada SMAK Giovani. Hal ini tentu sangat menyulitkan bagian tata uaha dalam melakukan pencarian kembali informasi tentang data siswa dan melakukan pengolahan data siswa. Hasilnya informasi yang dikelola tidak mampe memberikan pelayanan secara maksimal. Penelitian ini menggunakan model pengembangan sistem classic life cycle (waterfall model). Metode waterfall adalah metode pengembangan aplikasi perangkat lunak yang dilakukan secara terstruktur. Sistem informasi yang dihasilkan ini dapat membantu pihak sma katolik diovani kupang untuk lebuh meudah dan cepat mendata siswanya.', 'Aplikasi Mobile', 'Software', 'PHP', 'Emiliana Meolbatak, ST.MT', 'Yulianti P. Bria Seran, S.T., MM', 'Paskalis A. Nani, ST.MT', 'Natalia M.R. Mamulak, S.T., MM', 2017),
(31, 23109022, 'Benediktus paskalis bitin', 'Sistem informasi akuntansi berbasis internet dengan menggunakan codeigneter framework dan mtsqlpada', 'CV Amarta adalah Cv yang bergerak di bidang konstruksi yang setiap harinya, pemasukkan data-data transaksi keuangan dilakukan secara manual oleh staf keuangan. Transaksi keuangan hanya dicatat pada buku keuangan yang ada pada CV Amatra saja, shingga bila staf bagian keuangan besangkutan sedang berada diluar CV, maka tidak bisa melakukan transaksi keuangan. Untuk mengatasi permasalahan tersebut, maka dibuat suatu aplikasi sinstem informasi akuntansi yang menggunakan codeigmitr framework sehingga membantu pekerjaan staf keuangan dan pimpinan dalam melihat informasi keuangan pada CV Amarta. Sistem informasi akuntansi dibangun menggunakan metode waterfall dengan bahasa oemrograman PHP dan MYSQL sebagai databasenya. Hasil dari penelitian ini adalah suatu sistem informasi akuntansi yang membantu pimpinan dalam mengelola transaksi-transaksi keuangn yang ada pada CV Amarta secara cepat dan akurat', 'Aplikasi Mobile', 'Software', 'PHP', 'Donatus J. Manehat, S.Si,.M.Kom', 'Emerensiana Ngaga,ST.MT', 'Emiliana Meolbatak,ST.MT', 'Yulianti P. Bria,ST,MT', 2017),
(32, 23111085, 'Arnaldo paskalis bere', 'Sistem pendukung keputusan penentuan pegawai berprestasi menggunakan metode multifactor evalation pr', 'Dinas perumahan rakyat dan kawasan pemukiman provinsi nusa tenggara timur (NTT) merupakan salah satu instansi yang bergerak dalam bidang infrastruktur perumahan dan kawasa pemukiman di NTT dimana pegawai berperan besar dalam menentukan pegawai berprestasi dilakukan 2 kali dalam setahun. Akan tetapi belumada suatu sistem yang mendukung dalam proses penilaian pegawai berprestasi, serta belum tersedianya sistem yang akan mendokumentasikan penilaian pegawai berprestasi. Sistem pendukung keputusan menjadi alternatif yang dipakai untuk mendukung pengambilan keputusan penetuan pegawai berprestasi dengan menggunakan metode multifactor evalution process. Dengan menekankan pada penggunaan sistem penilaian yang objektif akan memberikan hasil penilaian yang sesuai. Pengembangan perangkat lunak ini menggunakan bahas a pemrograman basic dan microsoft access 2007 sebagai databasenya. Sistem yang dibangun mempercepat proses pengambilan keputusan pegawai berprestasi pada dinas perumahan rakyat dan kawasan pemukiman provinsi NTT dan penilaiannya dapat tersimpan secara baik dari tahun ke tahun untuk melihat perubahan prestasi pegawai. ', 'Aplikasi Mobile', 'Software', 'PHP', 'Emerensiana Ngaga,ST.MT', 'Emerensiana Ngaga,ST.MT', 'Paulina Aliandu, ST,M.Cs', 'Ign. Pricher A.N. Samane,S.Si.M.Eng', 2017),
(33, 23112031, 'Monika suares', 'Pemanfaatan speech recognition dalam promosi taman ziarah yesus maria oebelo kupang berbasis website', 'Teknologi speech recogration merupakan teknologi pengenal wicara yang memanfaatkan sinyal manusia sebagai masukan untuk kemudian dikenali oleh komputer. Adapun permasalahan yang dihadapi pengelola Taman Ziara yaitu masih kurangnya minat kunjung pada masyarakat untuk datang berziarah, dan dengan adanya speech recognition dapat membantu pengelola dalam mempromosikan taman ziarah agar dapat menarik minat pengunjung dari sharing pengunjung sebelumnya. Oleh karena itu pengunjung lebih mudah dalam penulisan buku tamu dan semua kegiatan yang ada di taman ziarah agar dapat memberikan kesan kepada pengunjung. Tujuan dari pemanfaatan speech recognition ini adalah membantu pengelola Taman Ziarah Yesus Maria Oebelo untuk memperkenalkan Taman Ziarah Yesus Maria Oebelo untuk berbagai kepentingan masyarakat luas dalam kegiatan kerohanian. \r\nPerancangan aplikasi ini menggunakan metode waterfall, dalam metode ini terdapat lima tahapan yaitu tahap analisis, desain, implementasi, pengujian, dan pemeliharaan. Sistem ini dirancang menggunakan bahasa pemograman PHP dan desain menggunakan Macromedia Dreamweaver MX 2004 sera MySQL sebagai penyimpanan datanya.\r\nDari aplikasi ini diharapkan pengelolah dapat mempromosikan taman ziarah yesus maria oebelo dengan memanfaatkan speech recognition dan berinteraksi langsung tanpa menggunakan mouse dan keyboard.\r\n', 'Aplikasi Mobile', 'Software', 'PHP', 'Frengky Teddy, ST,MT', 'Ign. Pricher A.N. Samane,S.Si.M.Eng', 'Yulianti P. Bria,ST,MT', 'Natalia M.R. Mamulak, S.T., MM', 2017),
(34, 23111081, 'Juliaberto dosreis', 'Rancang bangun aplikasi media pembelajaran pengenalan seni dan budaya di timor leste berbasis multim', 'Timor Leste merupakan negara yang terdiri dari banyak Distrik memiliki berbagai macam suku bangsa, bahasa adat istiadat atau sering kita sebut kebudayaan. Keanekaragaman budaya yang terdapat di Timor Leste merupakan suatu bukti bahwa Timor Leste merupakan negara yang sangat kaya akan budaya. Timor Leste juga terdiri dari berbagai suku dan segala jenis macam budaya yang terdiri dari rumah adat, pakaian adat, tarian dan musik tradisional. Dalam hal mengenal rumh adat, pakaian adat, tarian dan musik tradsional di Timor Leste perlu adanya media pembelajaran yang interaktif dan efisien yang dapat membuat siswa lebih memahami budaya Timor Leste dimana cara ini perlu diterapkan pada siswa kelas 4 SD SAO MIGUEL HOLSA MALIANA. \r\nProses pembelajaran yang sedang berjalan saat ini masih bersifat konvensional dan cenderung membuat siswa merasa bosan dan kurang dimengerti. Oleh karena itu perlu adanya suatu media pembelajaran yang dikemas lebih menarik dan menumbuhkan minat belajar siswa, salah satunya dengan aplikasi multimedia sebagai media pembelajaran bagi siswa kelas 4 SD SAO MIGUEL HOLSA MALIANA untuk mengenal rumah adat, pakaian adat, tarian, musik tradisional di Timor Leste.\r\nDalam merancang bangun aplikasi ini metode yang digunakan adalah metode tahapan pengembangan multimedia dimana metode tersebut meliputi tahap concept (pengonsepan(, design (perancangan), Material Coleecthing(pengumpulan Bahan), Assemblu(pembuatan), testhing(pengujian), distribution(distribusi).\r\nHasil akhir yang dicapai dari aplikasi ini dapat menarik minat anak-anak agar mau mengenal budaya Timor Leste yang terdiri dari beberapa jenis yaitu rumah adat, pakaian adat, tarian dan musik tradisional untuk menumbuhkan rasa kecintaan mereka pada kebudayaan Timor Leste.\r\n', 'Aplikasi Mobile', 'Software', 'PHP', 'Emerensiana Ngaga,ST.MT', 'Natalia M. Mamulak, ST.MM', 'Sislia Daeng Baka Mau,S.Kom.MT', 'Frengky Teddy, ST,MT', 2017),
(35, 23110083, 'Muhamad wawan suwandi', 'Aplikasi pengolahan data peserta dan calon penerima pensiun pada pt. taspen (persero) cabang kupang', 'Sistem pengolahan data merupakan salah satu cara yang dipakai dalam setiap lembaga untuk memaksimalkan sumber daya agar dapat menghasilakan output yang sesuai dengan kebutuhan.d alam mengolah data dibutuhkan setiap ouput yang sesuai agar dalam pelaksanaan pengolahan data setiap ouput yang dihasilkan harus sesuai berdasarkan inputan awal. Pt taspes persero merupakan salah satu lembaga yang menggunakan sistem pengolahan data berbasis komputer dlam mengolah data peserta dan calon penerima pensiun. Sistem ini dibangun dengan tujuan untuk mebantu para peserta dalam mempermudah mengolah data sehingga tidak mengurangi sumber daya. Sistem ini menggunakan metode UP (unfiled proces) yang terdiri dari  4 tahapan yaitu : inception, elaboration, constraction, transition dengan menggunakan tools neatbeans dan mysql sebagai basis data dengan bahasa pemrograman java. Hasil dari pembuatan aplikasi ini mampu memberikan kemudahan dalam pengolahan data khususnya data peserta dan calon penerima pensiun sehingga lebih efektif ', 'Keamanan Informasi', 'Hardware', 'PHP', 'Yulianti P. Bria, ST.MT', 'Emerensiana Ngaga,ST.MT', 'Natalia M. Mamulak, ST.MM', 'Frengky Teddy, ST,MT', 2017),
(36, 23111012, 'Oseias octereni Ximenes baros', 'Sistem informasi geofrafis wisata kuliner kota kupang berbasis web menggunakan google api', 'Wisata kuliner adalah sebuah potensi daerah yang sangat baik untuk dikembangkan. Nilai manfaat ekonomi dan dampaknya sangat luas. Pengelolaan informasi dan dukungan promosi yang tepat akan sangat membantu meningkatkan usaha di bidang kuliner ini. Salah satumedia promosi yang dapat digunakan adalah dengan menyediakan media informasi wisata kuliner yang mudah diakses oleh masyarakat luas dan akurasi informasi yang baik. Media informasi tersebut juga dapat di update oleh user yang telah terdaftar. Pemanfaatan teknologi informasi yang saat ini berkembang, merupakan sebuah strategi yang tepat dalam rangka memperkenalkan potensi kuliner suatu daerah. Sistem informasi bebasis web dan mempergunakan visualisasi produk dan lokas (peta) akan mempermudah masyarakat dalam mencari dan menjangkau lokasi kuliner. Sistem informasi Geografis yang memanfaatkan teknologi Google Maps API dapat menjawab kebetulan tersebut. \r\nSistem Informasi Geografis Wisata Kuliner memberikan sebuah aplikasi web yang menampung dan mempublikasikan informasi pusat-pusat kuliner suatu daerah (dalam hal ini kota Kupang). Informasi yang ditampilkan dalam bentuk peta memberikan kemudahan pengguna dalam mencari informasi dan selanjutnya akan semakin mendorong minat untuk mengunjungi lokasi.\r\n', 'Keamanan Informasi', 'Hardware', 'PHP', 'Natalia M. Mamulak, ST.MM', 'Frengky Teddy, ST,MT', 'Patrisius Batarius, ST.MT', 'Ign. Pricher A.N. Samane,S.Si.M.Eng', 2018),
(37, 23111098, 'Yohanes klaudius ria biru', 'Aplikasi pengenalan jenis nyamuk berbahaya dan bahayanya bagi manusia berbasis multimedia', 'Nyamuk merupakan serangga yang sering kali membuat orang terganggu aibat gigitannya. Salah satu bahaya yang disebabkan oleh gigitan nyamuk adalah berbagai macam penyakit yang bahkan dapat menyebabkan kematian. Data dari Dinas Kesehatan NTT mencatat bahwa khusus untuk Kota Kupang, rata-rata khasus malaria klinis dari tahun 2014-2015 mencapai 181 kasus per 1000 orang pertahun, bahkan di tahun 2014 mencapai 205 kasus per 1000 orang pertahun. Dinas Kesehatan merupakan salah satu instansi pemerintah yang aktif melakukan sosialisasi dalam memberikan informasi tentang kesehatan, salah satunya tentang bahaya nyamuk. Namun media yang digunakan dalam sosialisasi masih brupa media presentasi biasa, seperti melalui media poster atau selebaran sehingga sosialisasi yang dilakukan pada masyarakat masih sederhana dan sosialisasi pun belum menjangkau ke semua kalangan masyarakat yang masih minim akan pengetahuan bahaya nyamuk, sedangkan terapat banyak jenis penyakit yang disebabkan oleh berbagai jenis nyamuk yang berbeda. Metode dalam penelitian yang akan digunakan adalah Metode tahapanpengembangan multimedia meliputi tahap concept(pengonsepan),design(perancangan) Material Collecting (pengumpulan bahan), Assembly (pembuatan),Testing(pengujian), Distribution (distribusi). Hasil akhir yang ingin dicapai adalah sebuah aplikasi media informasi yang mampu menarik minat masyarakat umum dalam mendapatkan informasi tentang jenis-jenis nyamuk, penyakit yang disebabkan, pencegahan dan pengobatan serta membantu para tenaga medis lebih mudah dan efektifdalam proses penyampaian informasi.', 'Keamanan Informasi', 'Hardware', 'PHP', 'Donatus J. Manehat, S.Si,.M.Kom', 'Patrisius Batarius, ST.MT', 'Natalia M. Mamulak, ST.MM', 'Frengky Teddy, ST,MT', 2018),
(38, 23113003, 'Christianto dedy diong', 'Aplikasi praktek dokter anak berbasis android pada apotik panacea kota kupang', 'Teknologi cangguh yang berkembang pesat adalah sistem operasi untuk telepon selular yakni Android. Dengan adanya teknologi Adroid pengguna telepon selular dapat melakukan kreasi dendiri ataupun mengundah aplikasi Android yang kemudian digunakan pada telepon pintar(Smartphone). Peran smartphone tidak hanya dirasakan dalam kehidupan manusia sehari-hari tetapi juga dirasakan dalam berbagai sektor bidang kehidupan seperti bidang pendidikan, perbankan, pemerintahan, politik, bisnis dan juga bidang kesehatan.  Apotik Panacea melakukan pelayanan setiap hari yang dibuka pada jam 5 sore sampai dengan jam 9 malam dengan rata-rata kunjungan pasien 18-25 orang/hari.\r\nKendala-kendala yang dihadapi klinik praktek dokter anak, dalam hal pengambilan nomor antrian dan informasi tentang jadwal dokter dapat dilakukan dengan harus datang langsung ke tempat praktek, untuk itu diperlukannya pengembangan suatu aplikasi yang memanfaatkan teknologi smartphone yang bisa mengatasi kendala-kendala yang dihadapi klinik praktek dokter anak, dalam hal pengambilan nomor antrian dan informasi tentang jadwal dokter dapat dilakukan dengan tanpa harus datang langsung ke tempat praktek. Metode rekayasa perangkat lunak yang digunakan adalah model klasikyang bersifat sistematis, berurutan dalam membangun software. Nama model ini sebenarnya adalah â€œLinear Squential Modelâ€. Model ini sering disebut dengan â€œclassic life cycleâ€ atau model waterfall. Tools yang digunakan dalam aplikasi ini menggunakan XAMPP, Neatbeans, Adroid Studio dengan menggunakan bahasa pemograman Java dan Kotlin.\r\n', 'Keamanan Informasi', 'Hardware', 'PHP', 'Emiliana Meolbatak, ST.MT', 'Emerensiana Ngaga,ST.MT', 'Paskalis A. Nani, ST.MT', 'Sislia Daeng Baka Mau,S.Kom.MT', 2018),
(39, 23111011, 'Christoforus M.A baga', 'Media informasi penyakit Kusta berbasis multimedia', 'Penyakit kusta (Hansen) adalah penyakit infeksi, yang disebabkan akteri Mycobacterium leprae. Bakteri ini dapat menyebabkan kerusakan permanen pada kulit, saraf dan anggota gerak mata, organ tubuh manusia terutama kulit. Penyakit kusta ini juga merupakan suatu penyakit yang masih menjadi pusat perhatian dunia dan sampai saat ini belum ada satu negara manapun yang bebas dari penyakit kusta. Selain kustau, terdapat beberapa penyakit yang termasuk dalam penyakit kulit yaitu penyakit kudis, kurap dan panu. Dari beberapa penyakit tersebut terdapat beberapa gejala yang mirip dengan penyakit kusta seperti kudis, kurap dan panu. Kemiripan gejala-gejala tersebut antara lain, seperti panu ada bercak tipis pada tubuh manusia, kusta terdapat bercak-bercak dan berakhir dengan kebotakan. Pemilihan multimedia sebagai basis dari media ini dikarenakan multimedia dapat menghasilkan media informasi yang menarik dalam segi tampilan antar muka, sehingga dapat menarik minat para pengguna untuk melihat, menggunakan dan mempelajari media informasi ini melalui media informasi penyakit kusta ini nantinya, pengguna dimungkinkan untuk mengetahui informasi lengkap tentang gejala-gejala, ciri-ciri penyebab, pencegahan dan pengobatanterhadap penyakt kusta ini. ', 'Optimasi', 'Software', 'PHP', 'Ignatius P.A.N. Samane, S,Si, M.Eng', 'Ign. Pricher A.N. Samane,S.Si.M.Eng', 'Donatus J. Manehat, S.Si, M.Kom', 'Sislia Daeng Baka Mau,S.Kom.MT', 2018),
(40, 23112043, 'Arza andronikus bano', 'Multimedia pembelajaran teknik budidaya jamur tiram', 'proses pembelajaran untuk membudidayakan jamur tiram saat ini masih menggunakan metode ceramah dan juga belajar dari buku. Hal ini merupakan sebuah kendala dalam proses pembelajaran yang menyebabkan para petanu pemula kurang mengerti materi yang diajarkan dikarenakan kurangnya fasilitas dan media alternatif untuk membuat kombinasi pembelajaran. Oleh karena itu dibutuhkan media pembelajaran alternatif berbasis multimedia yang dapat membantu petani jamur agar bisa belajar kapanpun. Metode yang digunakan adalah pengembangan multimedia dengan langkah-langkah yang harus diikuti untuk menghasilkan produk yang berupa rancangan aplikasi multimedia. Langkah-langka dalam metode perancangan meliputi : 1. Concept(konsep) 2. Design(perancangan) 3. Material collecting (pengumpulan bahan) 4. Assembly (pembuatan) 5. Testing (pengujian aplikasi) 6. Distribution. Hal yang diperoleh dari pembuatan aplikasi ini adalah agar para petani jamur mampu memahami materi dan praktik budidaya jamur tiram serta mengetahui manfaat dan perawatan ketika melakukan produksi jamur tiram.', 'Optimasi', 'Software', 'Solidity', 'Emiliana Meolbatak, ST.MT', 'Emiliana Meolbatak, ST.MT', 'Donatus J. Manehat, S.Si, M.Kom', 'Patrisius Batarius, ST.MT', 2018),
(41, 23111029, 'Maria Christine L wuran', 'Rancang bangun sistem pakar untuk mendiagnosis penyakit kulit dengan metode forward chaninning', 'Dampak positif yang sangat terasa dari perkembangan teknologi adalah semakin mudahnya segala pekerjaan manusia yang dibantu oleh aplikasi komputer dan komputerlah yang bertindak sebagai pakarnya. Sistem pakar untuk mendiagnosis penyakit kulit dengan metode forward chaining pada RSUD Dr. Hendrikus Fernandez. Larantuka dibangun dengan Bootsrap 3.3.7. metode pengembangan sistem yang digunakan adalah expert system life cycle dimana semua kntrol aplikasi diuji dengan menggunakan teknik blackbox testing menunjukkan semua menu dan contoh pada aplikasi berjalan sesuai harapan pengguna. Hasil penelitian yang diperoleh adalah bahwa pelayanan diagnosis penyakit kulit pada RSUD Dr. Hendrikus Fernandez. Larantuka menjadi semakin mudah dibanding pelayanan sebelumnya walau masih sangat kurangnya tenaga medis atu dokter ahli penyakit kulit serta peralatan medis yang masih kurang memadai pula.', 'Aplikasi Mobile', 'Software', 'PHP', 'Donatus J. Manehat, S.Si,.M.Kom', 'Emerensiana Ngaga,ST.MT', 'Ign. Pricher A.N. Samane,S.Si.M.Eng', 'Sislia Daeng Baka Mau,S.Kom.MT', 2018),
(42, 23111071, 'Yuventus harianto bere eli', 'Sistem informasi geografis wilayah kediaman suku-suku di NTT berbasis web', 'Provinsi Nusa Tenggara Timur memiliki suku-suku beranekaragam sesuai dengan ciri khas dan adat istiadat budaya setempat. Suku-suku ini mendiami semua kabupaten yang ada di Provinsi Nusa Tenggara Timus. Suku-suku yang mendiami Provinsi NTT berjumlah 14 suku 34 sub suku. Dengan banyaknya suku-suku tersebut sangat sulit bagimasyarakat untuk membedakan asal suku yang satu dengan suku yang lainnya karena belum adanya media atau aplikasi untuk memberikan informasi tentang wilayah kediaman dominan suku-suku. Dalam menyelesaikan masalah tersebut maka dapat dirancang sebuah sistem informasi geografis berbasis web untuk membantu masyarakat agar lebih mengenal suku-suku yang mendiami Provinsi NTT melalui media atau aplikasi berbasis web Aplikasi yang dibangun menggunakan model SDLC (System Development Life Cycle) dan bahasa pemograman PHP dengan format database menggunakan MySQL.', 'Aplikasi Mobile', 'Software', 'PHP', 'Donatus J. Manehat, S.Si,.M.Kom', 'Paulina Aliandu, ST,M.Cs', 'Ign. Pricher A.N. Samane,S.Si.M.Eng', 'Natalia M.R. Mamulak, S.T., MM', 2018),
(43, 23111066, 'Ariel laba', 'Sistem pendukung keputusan penentuan guru terbaik pada dinas pendidikan upt wilayah menggunakan meto', 'Guru adalah pendidik profesional yang mempunyai tugas, fungsi dan perang penting dalam mencerdaskan kehidupan bangsa. Agar fungsi dan tugas yang melekat pada jabatan fungsional guru dilaksanakan sesuai dengan aturan yang berlaku. Dinar Pendidikan Unit Palayanan Terpadu (UPT) Wilayah 1 (Kota Kupang, Kabupaten Kupang, dan Kabupaten TTS) yang menaungi guru untuk tingkat Sekolah Menengah Atas (SMA) setiap tahun melakukan penilaian prestasi kerja guru untuk mendorong peningkatan profesionalitas guru dengan cara memantau kerja guru dalam mengimplementasikan tugasnya sehingga dapat mencapai standar kompetensi yang telah ditentukan. Masalah dalam penelitian ini adalah dasar pengambilan keputusan penilaian prestasi guru masih dilakukan secara subyektif, sehingga dapat terjadi bisa dalam penilaiannya, serta ketersediaan data-datanya masih dilakukan secara manual. Berdasarkan masalah penilaian diatas, maka tujuan penelitian ini adalah untuk membangun atau menyusun sebuah aplikasi yang dapat membantu tugas pengawas pada UPT Pendidikan Wilayah I, agar memudahkan dalam pengambilan keputusan penilain guru terbaik tingkat SMA.\r\nProses pengambilan keputusan guru terbaik, memerlukan sebuah sistem pendukung keputusan, yang secara umum didefinisikan sebagai sebuah sistem yang mampu menghasilkan pemecahan maupun penanganan masalah. Sistem pendukung keputusan tidak dimaksudkan untuk menggantikan peran pengambil keputusan, tapi untuk membantu dan mendukung pengambil keputusan. Salah satu metode yang digunakan dalam sistem pendukung keputusan penentuan Guru Terbaik adalah metode Profile Matching, dengan tahapan-tahapannya adalah sebagai berukut : menganalisis nilai target, nilai bobot, nilai core factor, nilai secondary factor dan melakukan perangkingan hasil akhir penilaian. Dengan metode perangkingan yang ada dapat membantu penilaian guru terbaik akan lebih tepat karena didasarkan pada nilai kriteria dan bobot yang sudah ditentukan sehingga akan mendapatkan hasil yang lebih maksimal.\r\nBerdasarkan hasil pembahasan, dapat disimpulkan bahwa: Sistem Pendukung Keputusan Penentuan Guru Terbaik dapat membantu seorang pengawas untuk melakukan pengelolahan data sasaran kerja pegawai negeri sipil yang dikhususkan pada guru mata pelajaran. Sistem pendukung juga dapat membantu kepala dinas Bidang Pendidikan dalam menentukan guru yang sesuai untuk menjadi guru terbaik tingkat SMA. \r\n', 'Aplikasi Mobile', 'Software', 'PHP', 'Donatus J. Manehat, S.Si,.M.Kom', 'Paulina Aliandu, ST,M.Cs', 'Patrisius Batarius, ST.MT', 'Paskalis A. Nani,ST.MT', 2018),
(44, 23111059, 'Oscar lopes', 'Sistem informasi geografis tempat pengisian air tangki kota kupang berbasis web', 'Kota Kupang memiliki 6 daerah kecamatan. Kebutuhan akan air bersih untuk setiap penduduk tidak merata. Jasa penjualan air dengan tengki banyak dilakukan di kota kupang untuk melayani kebutuhan air bersih di 6 kecamatan. Masyarakat tidak mengetahui lokasi dimana tempat pengisian air tengki, profil, kondisi selain yang memiliki oleh pemda kota kupang. Selain itu para sopir yang mengantar air juga tidak mengetahui persis pelanggan yang memesan air tengki. Pemilik pengisian air tengki, juga membutuhkan media promosi lokasi pengisian air. Penelitian ini bertujuan untuk membuat sistem informasi geografis lokasi pengisian air tengki di kota kupang. Penelitian ini menjawab kebutuhan sistem para pelanggan, sopir, dan pemilik pengisian air tengki. Pengembangan sistem informasi geografis menggunakan metode waterfall, sistem yang dibangun berbasis web menggunakan php dab databasenya menggunakan mysql.', 'Aplikasi Mobile', 'Software', 'PHP', 'Patrisius Batarius, ST.MT', 'Frengky Teddy, ST,MT', 'Emiliana Meolbatak,ST.MT', 'Natalia M.R. Mamulak, S.T., MM', 2018),
(45, 23112032, 'Yohanes renoldus nua', 'Multimedia pembelajaran pernapasan manusia dan infeksi pada saluran pernapasan untuk siswa kelas VII', 'Proses pembelajaran biologi pada materi sistem pernapasan manusia SMP Negeri 1 Mamboro Sumba Tengah saat ini masih menggunakan metode belajar ceramah. Hal ini merupakan sebuah kendala dalam proses pembelajaran yang menyebabkan siswa kurang mengerti materi yang diajarkan dikarenakan kurangnya fasilitas dan media alternatif untuk membuat kombinasi pembelajaran. Oleh karena itu dibutuhkan pengembangan media pembelajaran yang mampu memuat berbagai jenis text, audio dan video yang dapat membantu dalam sebuah pemebelajaran, salah satunya adalah media pemeblajaran berbasis multimedia. Metode yang digunakan adalah pengembangan multimedia dengan langkah-langkah yang harus diikuti untuk menghasilakan produk yang berupa perancangan meliputi : kosep, perancangan, pengumpulah bahan, pembuatan, pengujian aplikasi dan distribusi. Hasil yang diperoleh dari pembuatan aplikasi ini adalah, agar para siswa mampu memahami materi pernapasan manusia dan infeksi pada saluran pernapasan serta mengetahui fungsi organ-organ pernapasan manusia.', 'Aplikasi Mobile', 'Software', 'PHP', 'Emiliana Meolbatak, ST.MT', 'Sislia Daeng Baka Mau,S.Kom.MT', 'Donatus J. Manehat, S.Si, M.Kom', 'Paulina Aliandu, ST,M.Cs', 2018),
(46, 23113017, 'Maria yunita hoar', 'Rancang bangun sistem informasi layanan umat pada gereja santa maria gunung karmel tumu', 'Gereja santa maria gunung karmel tumu merupakan sebuah proki yang terletak di kabupaten Timor Tengah Selatan berada di dusun Teufbuâ€™u kecamatan Amanutun Utara. Gereja ini terbagi menjadi beberapa bagian kecil, mulai dari pembagian wilayah, pembagian stasi, pembagian kelompok umat basis (KUB), dan pembagian kepala keluarga (kk). Tahun 2016 jumlah umat sebanyak 4.137 jiwa, dengan jumlah kelompok umat basis sebamyal 48 dan jumlah kepala keluarga sebanyak 800. Gereja ini di bagi menjadi 5 wilayah.permasalahan utama gereja santa maria gunung karmel tumu adalah proses pengolahn data umat yang masih besifat konvensional, sistem yang digunakan ini juga belum dapat merekap keseluruhan data-data umat dengan benar, baik dalam pengolahan, penyimpanan, pencetakan laporan, pembuatan laporan memakan waktu yang cukup lama, data mudah hilang sehingga menyebabkan ketidakurutan pada data tersebut. Berdasarkan permasalahan yang terjadi ini maka perlu dibuat sebuah sistem yang dapat membantu memperlancar proses penyimpanan informasi. Penelitian ini menggunakan metode wterfall, microsoft acces sebagai penyimpanan basis data dan visual basic sebagai bahasa pemrograman. Hasil dari pe nelitian ini adalah untuk membantu gereja santa maria gunung karmel tumu dalam menyajikan informasi secara akurat, cepat dan terorganisir mengenai kegiatan pelayanan umat-umat di gereja santa maria gunung karmel tumu. ', 'Aplikasi Mobile', 'Software', 'PHP', 'Emerensiana Ngaga,ST.MT', 'Alfry Aristo J. SinlaE, S.Kom. M.Cs', 'Donatus J. Manehat, S.Si, M.Kom', 'Frengky Teddy, ST,MT', 2018),
(47, 23112091, 'Asaria s. langasa', 'Sistem pakar penentuan media pembelajaran pendidikan berbasi android menggunakan model gagne reiser', 'Adapun permasalahan penmafaatan media media pembelajaran yang dihadapi oleh guru kelas IV di SD Inpres Oepura 2 adalah banyaknya media pembelajaran membuat guru kesulitan dalam menetukan media belajar yang sesuai dengan tujuan belajar sehingga mempengaruhi minat guru untuk memanfaatkan media pembelajaran sehingga berimplikasi pada pola pembelajaran yang monoton dan menjenuhkan. Aplikasi yang dibangun ini bertujuan untuk mebantu dan memudahkan guru untuk menentukan media pembelajaran yang sesuai dengan model flowchart yang dikembangkan oleh Ragne Reiser dan Anderson. Metode yang digunakan dalam rekayasa aplikasi ini adalah metode pemrograman terstruktur SDLC model waterfall dengan pengujian menggunakan teknik pengujian black box. Teknik penyelesaian masalah yang diimplementasikan dalam sistem pakar menggunakan metode forward chaining  sedangkan tools yang digunakan untuk membangun aplikasi ini adalah Java SDk, Eclipse dan Mysql. Aplikasi sistem ini mampu menentukan media pembelajaran pendidikan sesuai dengan metode flowchart yang dikembangkan oleh Gagne-Rieser dan Anderson. Serta menjawab permasalahan pemanfaatan media pembelajaran yang dihadapi oleh guru kelas 4 SD Inpres Oepura 2.', 'Aplikasi Mobile', 'Software', 'PHP', 'Emiliana Meolbatak, ST.MT', 'Sislia Daeng Baka Mau,S.Kom.MT', 'Paskalis A. Nani, ST.MT', 'Ign. Pricher A.N. Samane,S.Si.M.Eng', 2018),
(48, 23113090, 'Tiffany A. antonius', 'Rancang bangun social media sebagai sarana promosi pariwasata di ntt berbasis web', 'Destinasi wisata di Nusa Tenggara Timur (NTT) tidak kalah menarik dengan daerah lain di Indonesia. Namun banyaknya destinasi tidak dibarengi dengan pemiliharaan dan juga promosi  yang maksimal dari pemerintah. Oleh karena itu muncullah sebuah gagasan untuk membuat sebuat social media berbasis web, guna memberikan pembaruan yang akurat mengenai destinasi wisata dan memaksimalkan sistem promosi yang ada. Sistem ini dibuat menggunakan framework Boostrap dengan metode pengembangan sistem waterfall. Dengan terbentuknya website keliling NTT berkonsep social media, maka dapat disimpulkan bahwa website ini dapat memberikan informasi yang lebih luas dan menarik untuk dijadikan sebagai salah satu sarana promosi pariwisata NTT oleh para penggunanya.', 'Sistem Informasi', 'Software', 'Java', 'Patrisius Batarius, ST.MT', 'Alfry Aristo J. SinlaE, S.Kom. M.Cs', 'Emiliana Meolbatak,ST.MT', 'Paskalis A. Nani,ST.MT', 2018);
INSERT INTO `skripsi` (`id_skripsi`, `nim`, `nama`, `judul`, `abstrak`, `kategori`, `jenis_perangkat`, `bahasa_pemrograman`, `pembimbing_satu`, `pembimbing_dua`, `penguji_satu`, `penguji_dua`, `tahun`) VALUES
(49, 23113062, 'Osvaldus Yusditira R. Akoit', 'Multimedia pembelajaran interaktif teknisi dasar komputer bagi paserta magang (SMK) di CV Inodave', 'CV. Indonave merupakan perusahaan yang bergerak dibidang penjualan komputer, laptop dan aksesoris komputer. Selain itu, CV.Indonave juga menerima jasa service komputer, laptop, printer, dan pemasangan jaringan internet serta menerima peserta magang SMK dari dalam maupun luar nusa tenggara timur. CV. Indonave memiliki satu pengajar untuk melakukan bimbingan kepada 12 orang peserta magang. Peserta magang berasal dari SMK yang berada di wilayah nusa tenggara timur yang secara bergantian melakukan magang selam 3 bulan pada setiap periodenya. Latar belakang pembimbing yang bukan berasal dari guru, mengakibatkan pembimbing mengalami kesulitan dalam membimbing peserta magang. Adapun, masalah lain yang dialami ialah minimnya pengetahuan peserta magang dibidang TI. Metode yang digunakan dalam pembuatan aplikasi ini adalah metode pengembangan multimedia dan tools yang digunakan dalam membangun aplikasi adalah bahasa pemrograman Actionscript 2, bahasa pemrograman php, database mysql. Multimedia pembelajaran interaktif teknisi dasar komputer bagi peserta magang di CV. Indonave ini dapat memudahkan para peserta magang dalam proses belajar, dan mengulangi materi secara berulang-ulang. ', 'Sistem Informasi', 'Software', 'Java', 'Emiliana Meolbatak, ST.MT', 'Yovenia C. Hoar Siki, ST.MT', 'Patrisius Batarius, ST.MT', 'Alfry Aristo J. SinlaE, S.Kom. M.Cs', 2018),
(50, 23112104, 'Kritoforus m suku', 'Pengembangan sistem informasi kepegawaian pada dinas pendapatan daerah kabupaten TTU', 'Dinas pendapatan daerah kabupaten timur tengah utara merupakan salah satu instansi pemerintahan yang bergerak dalam bidang pemungutan, dalam hal ini budang pemungutan pajak dan retribusi yang melibatkan masyarakat sebagai wajib pajak dan wajib retribusi. Sistem informasi pengolahan data pada dinas pendapatan daerah kabupaten timor tengah utara sudah menggunakan komputer tapi penggunaanya masih standar yaitu menggunakan microsoft word dan excel dimana data pegawai, data pelatihan, data mutasi, data pensiun, dan data cuti diketik kemudia disimpan dalam bentuk folder-folder yang tidak beraturan sehinggamembutuhkan waktu yang lama dalam proses pencarian data-data pegawai jika sesekali waktu diperlukan. Hal ini terjadi karena belum adanya suatu database penyimpanan data. Dalam penelitian ini menggunakan metode unified process untuk pengembangan rekayasa perangkat lunak. Unified process memiliki empat tahapan yaitu inception, elaboration, constraction, dan transition. Aplikasi ini dibangun dengan menggunakan php, database mysql dan fpdf untuk desain laporan penyimpanan data. Penelitian ini menghasilkan sebuah sistem informasi pengolahan data pegawai dinas pendapatan daerah kabupaten timor tengah utara yang mempermudah dalam proses pengolahan data hingga pembuatan laporan dan surat.   ', 'Sistem Informasi', 'Software', 'Java', 'Patrisius Batarius, ST.MT', 'Patrisius Batarius, ST.MT', 'Donatus J. Manehat, S.Si, M.Kom', 'Paulina Aliandu, ST,M.Cs', 2018),
(51, 23114068, 'Olganius kepa sena', 'Aplikasi fuzzy logic untuk menentukan kualitas pengaspalan', 'Sistem pengaspalan jalan raya yang komposisi campuran Bahannya yang belum sempurna dikarenakan pada proses pencampuran material yakni agregat dan aspal serta suhu yang digunakan saat pemadatan masih menggunakan perkiraan saja tanpa ada perhitungan yang sistematis sehingga menyebabkan pengaspalan pada Jalan Raya tidak begitu sempurna. Hal ini dapat menyebabkan jalan raya tersebut tidak dapat bertahan lama karena tidak ada sistem pencampuran bahan untuk pengaspalan yang mengatur tentang komposisi jumlah dari tiap material dan suhu yang digunakan pada saat pencampuran. permasalahan pencampuran bahan pengaspalan ini dapat diatasi dengan melakukan pengaturan pada sistem pencampuran untuk pengaspalan. Salah satu cara yang dapat dilakukan adalah dengan menggunakan sistem kontrol logika Fuzzy atau sering disebut Fuzzy logic controller.Kontrol logika Fuzzy  Fuzzy logic controller merupakan kontrol yang didasarkan pada logika Fuji sistem matematika yang menganalisis nilai input variabel. terdapat tiga variabel inputan yang digunakan dalam menentukan kualitas pengaspalan yaitu agregat, aspal dan suhu. Dalam penelitian ini, digunakan metode pemrograman terstruktur model waterfall untuk membangun aplikasi Fuzzy Logic. Aplikasi ini dibangun dengan menggunakan bahasa pemrograman PHP dan database MySQL. metode logika Fuzzi yang digunakan adalah metode mamdani di mana defuzzifikasinya ialah centroid.Penelitian ini menghasilkan output berupa bilangan crips yaitu kurang baik, cukup baik, baik dan sangat baik sebagai acuan untuk melakukan campuran pengaspalan. aplikasi ini dapat membantu para pegawai atau pekerja maupun pengecek kualitas pengaspalan para CV bumi indah dalam mengetahui jumlah dari tiap material dan suhu yang digunakan untuk pemanasan dalam pencampuran dan mengetahui tingkat akurasi hasil perhitungan sistem.diperoleh dari pembuatan aplikasi ini adalah agar para petani jamur mampu memahami materi dan praktik budidaya jamur tiram serta mengetahui manfaat dan perawatan ketika melakukan produksi jamur tiram.', 'Sistem Informasi', 'Software', 'Java', 'Patrisius Batarius, ST.MT', 'Alfry Aristo J. SinlaE, S.Kom. M.Cs', 'Donatus J. Manehat, S.Si, M.Kom', 'Yovenia C. Hoar Siki, ST.MT', 2019),
(52, 23113025, 'Hendrikus b nenomnua', 'Aplikasi notifikasi suntik KB menggunakan SMS gateway', 'Kantor BKKBN provinsi NTT menjadi lembaga yang handal dan dipercaya dalam mewujudkan penduduk tumbuh seimbang dan keluarga berkualitas salah satunya dalam program Keluarga Berencana sistem yang digunakan dalam instansi Keluarga Berencana masih manual seperti dalam pemberian jadwal suntik kepada akseptor yang masih ditulis secara manual pada kartu akseptor, maka perlu dibuatnya suatu sistem yaitu aplikasi notifikasi jadwal suntik KB menggunakan SMS gateway sehingga memudahkan kantor BKKBN dalam memberikan informasi. metode penelitian yang digunakan terdiri dari metode pengumpulan data dan  pengembangan sistem, aplikasi notifikasi jadwal suntik KB menggunakan SMS gateway ini dibangun dengan bahasa pemrograman PHP, SMS gateway serta memanfaatkan database MySQL sebagai database server. dari hasil penelitian yang dilakukan menunjukkan bahwa jadwal suntik KB menggunakan SMS gateway dapat membantu akseptor dalam mendapatkan informasi jadwal suntik KB dan dapat juga memberikan kemudahan bagi kantor BKKBN Provinsi NTT untuk dapat melakukan program pelayanan masyarakat yang lebih baik.', 'Sistem Informasi', 'Software', 'Java', 'Sisilia D. B. Mau, S.Kom.MT', 'Yovenia C. Hoar Siki, ST.MT', 'Donatus J. Manehat, S.Si, M.Kom', 'Paulina Aliandu, ST,M.Cs', 2019),
(53, 23113079, 'Eric septian kristanto dasilva', 'Aplikasi layanan informasi E-KTP pada dispenduk kota kupang Berbasis android', 'Teknologi pada saat ini sangat berperan penting bagi perkembangan manusia. banyak kegunaan dari teknologi yang mempermudah baik pekerjaan, mencari informasi, serta melakukan komunikasi yang memudahkan Masyarakat khususnya dalam melakukan prosedur kepengurusan KTP elektronik aplikasi ini yang nanti dibuat agar mempermudah pencantulan dalam pengambilan KTP elektronik yang telah selesai dibuat melalui mobile. pengamatan permasalahan di instansi dinas kependudukan dan pencatatan sipil kota Kupang dilihat dari permasalahan di atas khususnya masyarakat di kota Kupang yang sulit dalam melakukan proses pembuatan e-ktp yang biasa ditemukan yaitu kurangnya informasi kepengurusan dan lamanya waktu pengambilan e-ktp metode pengembangan sistem yang digunakan dalam penelitian ini dengan metode waterfall. perancangan aplikasi yang ditampilkan dalam sistem ini menggunakan Android, bahasa pemrogramannya itu Dart dan MySQL sebagai database server. dengan adanya aplikasi ini yang akan dibangun mempermudah pencarian informasi dan jadwal pengambilan e-ktp tujuan dari penelitian ini adalah bagaimana Merancang dan membangun sebuah layanan informasi pengambilan e-ktp berbasis Android agar terjadwal dalam pengambilan e-ktp dan juga informasi seputar kepengurusan e-ktp dari kantor dinas kependudukan dan pencatatan sipil kota Kupang.', 'Sistem Informasi', 'Software', 'Java', 'Paulina Aliandu, ST,M.Cs', 'Paskalis A. Nani, ST.MT', 'Donatus J. Manehat, S.Si, M.Kom', 'Alfry Aristo J. SinlaE, S.Kom. M.Cs', 2019),
(54, 23113109, 'Indra evalindo tamoes', 'Klasifikasi penyakit sapi bali menggunakan algoritma K-Nearest Neighbor berbasis web', 'Sapi Bali telah terbesar hampir di seluruh provinsi di Indonesia dan berkembang cukup pesat di banyak daerah karena mempunyai daya adaptasi yang baik terhadap lingkungan yang buruk. namun ada beberapa faktor yang mempengaruhi pertumbuhan dan perkembangan sapi Bali, Salah satunya yaitu infeksi penyakit. Hal ini tentu berdampak pada peternak sapi Bali Karena kurangnya pengetahuan mengenai berbagai penyakit yang menyerang hewan ternaknya serta sulitnya mencari tenaga medis seperti dokter hewan sehingga peternak tidak dapat secara cepat menangani sapi yang terkena penyakit. oleh karena itu perlu dibuat suatu sistem yaitu klasifikasi penyakit sapi Bali menggunakan algoritma K-NN berbasis web sehingga memudahkan masyarakat dalam Mengidentifikasi jenis penyakit berdasarkan gejala-gejala yang muncul pada sapi. model yang digunakan dalam mengembangkan sistem ini adalah waterfall. model ini terdiri dari beberapa tahap yakni analisis, desain, implementasi, pengujian dan pemeliharaan. klasifikasi penyakit sapi Bali ini dibangun dengan bahasa pemrograman PHP, memanfaatkan database SQL sebagai database server serta menggunakan algoritma K-NN. klasifikasi penyakit sapi Bali menggunakan algoritma K-NN berbasis web Ini menghasilkan informasi kepada masyarakat mengenai jenis penyakit sapi Bali berdasarkan gejala-gejala pada website. informasi yang dihasilkan meliputi gejala jenis penyakit dan solusi penanganan awal.', 'Sistem Informasi', 'Software', 'Java', 'Paskalis A. Nani,ST.MT', 'Yovenia C. Hoar Siki, ST.MT', 'Donatus J. Manehat, S.Si, M.Kom', 'Alfry Aristo J. SinlaE, S.Kom. M.Cs', 2019),
(55, 23115011, 'Estefanus ulu bere', 'Aplikasi logika fuzzy untuk memprediksi tingkat produktivitas ayam petelur dengan metode mamdani ber', 'Ayam ras petelur merupakan salah satu ternak yang dapat memenuhi kebutuhan protein hewani, selain daging tentunya telur yang dihasilkan dapat dikonsumsi oleh manusia di kota Kupang, NTT ayam ras petelur sangatlah dibutuhkan oleh masyarakat sebagai sumber protein yang dihasilkan dari telur ayam ras petelur itu sendiri. dalam pemeliharaan ayam ras petelur perlu diperhatikan khusus karena ayam ras petelur rentan terhadap penyakit dan kondisi alam sekitarnya sehingga hasil produksi ayam akan terhambat faktor-faktor seperti pakan, suhu, kelembaban udara dan umur ayam juga dapat mempengaruhi hasil produksi ayam. masalah yang dihadapi ialah pada masa produksi para ternak masih sering mengabaikan faktor-faktor tersebut titik sehingga peternak sering memberi pakan tidak sesuai dengan umur ayam, dapat menurunkan jumlah produksi dan kualitas serta menambah resiko kerugian selama pemeliharaan. oleh karena itu, permasalahan dapat diatasi dengan cara menggunakan aplikasi logika Fuzzi untuk memprediksi tingkat produktivitas ayam petelur menggunakan metode mamdani dengan metode mean of Maximum(mom) untuk defuzzifikasinya.Bahasa pemrograman yang digunakan untuk membangun aplikasi ini adalah PHP. hasil dari penelitian ini ialah aplikasi logika fuzzi untuk memprediksi dan meningkatkan produktivitas ayam petelur serta menghasilkan output hasil produksi telur ayam secara akurat dan tepat sehingga dapat membantu para peternak untuk mendapatkan hasil produksi telur yang optimal dan meminimalkan kerugian.', 'Sistem Informasi', 'Software', 'PHP', 'Sisilia D. B. Mau, S.Kom.MT', 'Emerensiana Ngaga,ST.MT', 'Paulina Aliandu, ST,M.Cs', 'Ign. Pricher A.N. Samane,S.Si.M.Eng', 2019),
(56, 23113103, 'Alfeu santo viktorino ', 'Perancangan Sistem Informasi Manajemen Keuangan dengan Metode Analisis Fundamental', '', 'Sistem Informasi', 'Software', 'Java', '', '', '', '', 2023),
(57, 23113105, 'Michael  minggus', 'Pengembangan Aplikasi E-learning dengan Fitur Chatbot', '', 'Aplikasi Mobile', 'Software', 'Java', '', '', '', '', 2023),
(58, 23112069, 'Nourberth andry yusuf maga', 'Pengembangan Aplikasi Mobile untuk Pelaporan Kejadian Kriminal', '', 'Aplikasi Mobile', 'Software', 'Java', '', '', '', '', 2023),
(59, 23114072, 'Azaryos y topan ', 'Pengembangan Aplikasi Mobile untuk Pemesanan Makanan dengan Metode Collaborative Filtering', '', 'Aplikasi Mobile', 'Software', 'Java', '', '', '', '', 2023),
(60, 23113049, 'Ayub umbu ngedo ndamalero', 'Pengembangan Aplikasi Mobile untuk Pelacakan Pengiriman Barang', '', 'Aplikasi Mobile', 'Software', 'Java', '', '', '', '', 2023),
(61, 23114096, 'Laura Felisa mangngi', 'Pengembangan Aplikasi Mobile untuk Pemesanan Tiket Pesawat', '', 'Aplikasi Mobile', 'Software', 'Java', '', '', '', '', 2023),
(62, 23113047, 'Ambrosius suni tnopo', 'Pengembangan Aplikasi Mobile untuk Monitoring Konsumsi Energi Listrik', '', 'Aplikasi Mobile', 'Software', 'Java', '', '', '', '', 2023),
(63, 23114115, 'Martinus robinson sumitro', 'Pengembangan Aplikasi Mobile untuk Monitoring Konsumsi Energi Listrik', '', 'Aplikasi Mobile', 'Software', 'Java', '', '', '', '', 2023),
(64, 23114065, 'Karolina yunita solle ', 'Pengembangan Aplikasi Mobile untuk Pencarian Tempat Parkir', '', 'Aplikasi Mobile', 'Software', 'Java', '', '', '', '', 2023),
(65, 23118036, 'Arlan Butar Butar', 'tes', 'tes', 'Sistem Informasi', 'Software', 'PHP', 'Paulina Aliandu, ST,M.Cs', 'Natalia M.R. Mamulak, ST,MM', 'Sisilia D.B Mau,S.Kom,MT', 'Frengky Teddy, ST,MT', 2023),
(66, 23117063, 'Katarina suryaningsih', 'Rancang bangun aplikasi inventaris barang berbasis web di smk negeri witihama', 'Aplikasi berbasis web di bidang pendidikan kini telah menawarkan berbagai kemudahan dalam membantu kegiatan belajar dan mengajar serta administrasi atau dalam hal ini inventaris barang sekolah di dalam lingkungan pendidikan SMK Negeri witihama merupakan salah satu institusi pendidikan di mana proses pendataan inventaris barangnya masih menggunakan pencatatan dalam buku dan setiap bulannya laporan inventaris barang sekolah masih dibuat menggunakan aplikasi Microsoft Excel. permasalahan lain yang sama Dalam proses inventaris adalah proses inventaris peralatan praktek yang tidak terkoordinir dengan baik sehingga menyebabkan banyak peralatan praktek yang hilang titik ketua jurusan sebagai penanggung jawab seringkali kesulitan dalam mempertanggungjawabkan peralatan praktek yang hilang tujuan penelitian ini adalah merancang bangun sebuah aplikasi inventaris barang berbasis web yang mencakup proses pendataan barang, baik barang habis pakai maupun tidak habis pakai, data pengadaan barang, data mutasi barang, data distribusi barang, data peminjaman dan pengambilan barang serta laporan-laporan yang diberikan dengan hal-hal tersebut seperti laporan mutasi barang dan laporan inventaris barang sekolah metode yang digunakan dalam merancang aplikasi inventaris barang berbasis web di SMK Negeri witihama adalah metode waterfall.Hasil dari penelitian ini berupa aplikasi berbasis web yang dapat membantu proses inventaris barang sekolah agar berjalan dengan lancar dan tidak ada lagi kesalahan terhadap data barang yang diinput serta memudahkan dalam proses pembuatan laporan bulanan inventaris barang sekolah dan membantu proses inventaris peralatan praktek agar terkoordinir dengan baik. \r\n\r\n', 'Aplikasi Mobile', 'Software', 'PHP', 'Donatus J. Manehat, S.Si,.M.Kom', 'Sislia Daeng Baka Mau,S.Kom.MT', 'Paskalis A. Nani, ST.MT', 'Alfry Aristo J. SinlaE, S.Kom. M.Cs', 2021),
(67, 23119133, 'lidwi', 'model regresi untuk memprediksi jumlah golongan', 'tujuan inin penelitian ini untuk memprediksi persedian darah di pmi ', 'Analisis Data', 'Software', 'Java', 'Patrisius Batarius, ST.MT', 'Sislia Daeng Baka Mau,S.Kom.MT', 'Donatus J. Manehat, S.Si, M.Kom', 'Alfry Aristo J. SinlaE, S.Kom. M.Cs', 2022),
(68, 23114005, 'Marianus naja', 'Sistem informasi kelompok tani kabupaten sikka berbasis web', 'Sistem informasi kelompok tani merupakan suatu sistem informasi yang berbasis web yang dapat mengelola penginputan data kelompok pertanian baik itu data petani maupun data hasil Tani serta pendataan lainnya Adapun pendataan kelompok petani masih menggunakan cara manual. belum ada sistem yang mengatur pendataan kelompok tani titik dalam membuat sistem informasi kelompok tani ini digambarkan dengan menggunakan arsitektur sistem, diagram konteks diagram arus data, pemodelan database dan ERD (entity relationship diagram).Tujuan dari penelitian ini adalah membuat aplikasi sistem informasi kelompok tani Kabupaten Sikka berbasis web pada Dinas Pertanian Kabupaten Sikka yang dapat memberikan kemudahan dalam pendataan kelompok tani. metode yang digunakan adalah metode waterfall. hasil dari penelitian ini berupa sistem informasi kelompok tani berbasis web yang dapat melakukan pengolahan data kelompok tani. aplikasi ini juga diharapkan dapat membantu Dinas Pertanian Kabupaten Sikka dalam melakukan pengelolaan data agar mudah dalam pendataan pendataan kelompok tani.', 'Sistem Informasi', 'Software', 'PHP', 'Patrisius Batarius, ST.MT', 'Sislia Daeng Baka Mau,S.Kom.MT', 'Donatus J. Manehat, S.Si, M.Kom', 'Ign. Pricher A.N. Samane,S.Si.M.Eng', 2021),
(69, 23117128, 'Richy ryonando marcus', 'Aplikasi edukasi bahasa inggris berbasis android untuk anak usia dini', 'Perkembangan smartphone sangat pesat sesuai dengan kebutuhan konsumen unjuk kerja yang optimal dibenamkan ke dalam setiap smartphone oleh per produsen agar semakin memiliki nilai jual. Seperti contohnya sistem operasi yang dipakai pada setiap smartphone. salah satu sistem operasi yang sedang populer saat ini adalah Android. Android merupakan sebuah sistem operasi berbasis Linux yang menyediakan platform terbuka bagi para pengembang untuk menciptakan aplikasi mereka sendiri. kecenderungan anak untuk bermain permainan yang ada pada gadget sangat besar karena menampilkan desain grafis yang cukup menarik. untuk anak usia PAUD tentu menjadi kendala dalam mempelajari bahasa baru, salah satunya bahasa Inggris yang cukup sulit dalam pengucapannya. Berdasarkan hasil pengamatan terhadap proses pembelajaran di PAUD grow kids, permasalahan yang mendasar pada pembelajaran bahasa Inggris yaitu bahasa Inggris merupakan bahasa baru yang diajarkan kepada anak Sehingga butuh metode khusus dalam pembelajaran titik Hal ini tentulah menjadi modal dasar pengembangan aplikasi edukasi bagi pembelajaran bahasa Inggris untuk anak-anak usia dini. metode yang digunakan dalam penelitian ini adalah unified process (UP)Dengan beberapa fase yaitu, Inception, elaboration, construction, Transition. aplikasi ini dibangun menggunakan Eclipse titik penelitian ini menghasilkan aplikasi edukasi Bahasa Inggris untuk anak usia dini, yang terdiri dari dua kategori yaitu kategori belajar dan bermain dengan maksud dapat meningkatkan kemampuan anak-anak usia dini mempelajari bahasa Inggris.\r\n\r\n', 'Aplikasi Mobile', 'Software', 'PHP', 'Emerensiana Ngaga,ST.MT', 'Paskalis A. Nani, ST.MT', 'Natalia M. Mamulak, ST.MM', 'Sislia Daeng Baka Mau,S.Kom.MT', 2021),
(70, 23117129, 'Fransiskus xaverius rakmeni', 'Pengembangan pembelajaran interaktif mata kuliah sistem respirasi materi bronliolitis pada stikes ma', 'Peningkatan kualitas pembelajaran memerlukan upaya yang menyeluruh termaksud kualitas pembelajaran di jurusan Keperawatan Stikes Maranatha Kupang salah satu bidang yang patut mendapat perhatian adalah mata kuliah sistem respirasi para pokok bahasan bronkiolitis. mata kuliah sistem respirasi dalam pokok bahasan bronkiolitis yang selama ini diajarkan masih menggunakan cara pembelajaran yang bersifat klasik yaitu masih menggunakan buku, sementara materi bronkiolitis memiliki banyak gambar-gambar yang berkaitan dengan organ tubuh bagian dalam manusia yang rumit dan membutuhkan pemahaman lebih tinggi. tidak adanya alat peraga dan menjadi masalah yang sangat besar pada Stikes Maranatha Kupang karena jumlah mahasiswa banyak dan dosen pengasuh mata kuliah  bronkiolitis berjumlah dua orang. pembahasan mengenai bronkiolitis membutuhkan multimedia agar Mahasiswa dapat lebih memahami dan dapat menyerap materi dengan mudah materi bronkiolitis memuat materi tentang organ dalam manusia dan simulasikan berupa gambar-gambar sehingga dosen memerlukan waktu yang cukup banyak untuk menggambar dan mensimulasikan gambar-gambar tersebut menjadi sebuah rangkaian materi pembelajaran bronkiolitis berbasis multimedia dibangun menggunakan macromedia  8 dengan bahasa pemrograman action script 2 metode yang digunakan dalam pembangunan aplikasi adalah metode pengembangan multimedia. hasil dari penelitian ini adalah sebuah aplikasi pembelajaran interaktif bronkiolitis mata kuliah sistem respirasi berbasis multimedia yang dapat membantu proses pembelajaran menjadi lebih mudah untuk diserap oleh mahasiswa Stikes Maranatha Kupang.\r\n\r\n', 'Sistem Informasi', 'Software', 'PHP', 'Donatus J. Manehat, S.Si,.M.Kom', 'Emerensiana Ngaga,ST.MT', 'Emiliana Meolbatak,ST.MT', 'Sislia Daeng Baka Mau,S.Kom.MT', 2021),
(71, 23119010, 'Ferdy Chanel D.rc Lay', 'Pengelompokkan Topik skripsi', 'tes', 'Sistem Informasi', 'Software', 'PHP', 'Donatus J. Manehat, S.Si,.M.Kom', 'Frengky Teddy, ST,MT', 'Emiliana Meolbatak,ST.MT', 'Sislia Daeng Baka Mau,S.Kom.MT', 2021),
(72, 23118041, 'Itha Lay Kudji', 'Fakultas Teknik', 'tes', 'sistem informasi', 'software', 'php', '(0801118302) Frengky Tedy, ST, MT.', '(0802038601) Emerensiana Ngaga, ST,MT', '(0807098502) Sisilia Daeng Bakka Mau, S.Kom, MT', '(0823078702) Yulianti Paula Bria ST., MT', 2022),
(73, 231829434, 'IREN BRIGITA PASU', 'dfadsad', 'asdasdas', 'sistem informasi', 'software', 'solidity', '(0831038602) Paskalis Andrianus Nani, ST,MT', '(0804126301) P. David Amfotis, SVD, B.Th., MA', '(0828128502) Natalia Magdalena R. Mamulak, ST.,MM', '(0801118302) Frengky Tedy, ST, MT.', 2023),
(74, 2341, 'Evi', 'ssdds', 'sdd', 'aplikasi mobile', 'software', 'java', '(0828126601) Donatus Joseph Manehat, S.Si, M.Kom', '(0825126701) Emanuel Jando, S.Kom, MT', '(0801118302) Frengky Tedy, ST, MT.', '(0807098502) Sisilia Daeng Bakka Mau, S.Kom, MT', 2023),
(75, 23119001, 'Ronal', 'analisis sentimen', 'gg', 'data mining', 'software', 'orange', '(0831038602) Paskalis Andrianus Nani, ST,MT', '(0818098102) Ignatius P. A. N. Samane, S Si., M Eng', '(0723057201) Dr. Adri Gabriel Sooai, ST,MT', '(0807078704) Alfry A. J.Sinlae, S.Kom., M.Cs.', 2023),
(76, 23119002, 'Desry', 'pengolahan citra', 'pengolahn hbhjbvhb', 'pengolahan citra', 'software', 'matlab', '(0831038602) Paskalis Andrianus Nani, ST,MT', '(0807098502) Sisilia Daeng Bakka Mau, S.Kom, MT', '(0828126601) Donatus Joseph Manehat, S.Si, M.Kom', '(0807078704) Alfry A. J.Sinlae, S.Kom., M.Cs.', 2023),
(77, 433222, 'olifa', 'penerapan', 'hjgj', 'analisis data', 'software', 'python', '(0802038601) Emerensiana Ngaga, ST,MT', '(0824047701) Emiliana Metan Meolbatak, ST, MT', '(0829087901) Paulina Aliandu, ST, M.Cs.', '(0805058803) Yovinia Carmeneja Hoar Siki, ST., MT', 2023),
(78, 23355, 'ulu', 'penerapan', 'tes', 'analisis data', 'software', 'python', '(0823078702) Yulianti Paula Bria ST., MT', '(0801118302) Frengky Tedy, ST, MT.', '(0805058803) Yovinia Carmeneja Hoar Siki, ST., MT', '(0828128502) Natalia Magdalena R. Mamulak, ST.,MM', 2023),
(79, 2324354, 'Kun lesek', 'sddsf', 'hcc', 'pengolahan citra', 'software', 'solidity', '(0828126601) Donatus Joseph Manehat, S.Si, M.Kom', '(0801118302) Frengky Tedy, ST, MT.', '(0723057201) Dr. Adri Gabriel Sooai, ST,MT', '(0807098502) Sisilia Daeng Bakka Mau, S.Kom, MT', 2023),
(80, 12345, 'aadsa', 'ffgf', 'gdfgd', 'pengolahan citra', 'software', 'python', '(0723057201) Dr. Adri Gabriel Sooai, ST,MT', '(0802038601) Emerensiana Ngaga, ST,MT', '(0825126701) Emanuel Jando, S.Kom, MT', '(0823078702) Yulianti Paula Bria ST., MT', 2023),
(81, 23412, 'qwe', 'fgaf', 'vcbbg', 'pengolahan citra', 'software', 'matlab', '(0824047701) Emiliana Metan Meolbatak, ST, MT', '(0829087901) Paulina Aliandu, ST, M.Cs.', '(0801118302) Frengky Tedy, ST, MT.', '(0807098502) Sisilia Daeng Bakka Mau, S.Kom, MT', 2023),
(82, 345, 'erf', 'fggf', 'bfbf', 'analisis data', 'software', 'python', '(0807098502) Sisilia Daeng Bakka Mau, S.Kom, MT', '(0801118302) Frengky Tedy, ST, MT.', '(0823078702) Yulianti Paula Bria ST., MT', '(0805058803) Yovinia Carmeneja Hoar Siki, ST., MT', 2023),
(83, 231807, 'dita', 'dadu', 'sAS', 'pengolahan citra', 'software', 'python', '(0825126701) Emanuel Jando, S.Kom, MT', '(0825126701) Emanuel Jando, S.Kom, MT', '(0723057201) Dr. Adri Gabriel Sooai, ST,MT', '(0829087901) Paulina Aliandu, ST, M.Cs.', 2023),
(84, 45667, 'adada', 'dfgghfgh', 'sgfngh', 'aplikasi mobile', 'software', 'php', '(0831038602) Paskalis Andrianus Nani, ST,MT', '(0828128502) Natalia Magdalena R. Mamulak, ST.,MM', '(0823078702) Yulianti Paula Bria ST., MT', '(0807098502) Sisilia Daeng Bakka Mau, S.Kom, MT', 2023);

-- --------------------------------------------------------

--
-- Struktur dari tabel `testing`
--

CREATE TABLE `testing` (
  `id_testing` int(11) NOT NULL,
  `id_skripsi` int(11) NOT NULL,
  `id_kelas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `testing`
--

INSERT INTO `testing` (`id_testing`, `id_skripsi`, `id_kelas`) VALUES
(1, 65, 1),
(2, 66, 2),
(8, 72, 2),
(9, 73, 1),
(10, 79, 2),
(11, 80, 2),
(12, 81, 2),
(13, 82, 1),
(14, 83, 1),
(15, 84, 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `training`
--

CREATE TABLE `training` (
  `id_training` int(11) NOT NULL,
  `id_skripsi` int(11) NOT NULL,
  `id_kelas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `training`
--

INSERT INTO `training` (`id_training`, `id_skripsi`, `id_kelas`) VALUES
(4, 15, 2),
(5, 16, 1),
(6, 17, 1),
(7, 18, 1),
(8, 19, 1),
(9, 20, 1),
(10, 21, 2),
(11, 22, 1),
(12, 23, 1),
(13, 24, 1),
(14, 25, 1),
(15, 26, 2),
(16, 27, 2),
(17, 28, 2),
(18, 29, 2),
(19, 30, 2),
(20, 31, 2),
(21, 32, 2),
(22, 33, 2),
(23, 34, 2),
(24, 35, 2),
(25, 36, 2),
(26, 37, 2),
(27, 38, 2),
(28, 39, 2),
(29, 40, 2),
(30, 41, 2),
(31, 42, 2),
(32, 43, 2),
(33, 44, 2),
(34, 45, 2),
(35, 46, 2),
(36, 47, 2),
(37, 48, 2),
(38, 49, 2),
(39, 50, 2),
(40, 51, 2),
(41, 52, 2),
(42, 53, 2),
(43, 54, 2),
(44, 55, 2),
(45, 56, 2),
(46, 57, 2),
(47, 58, 2),
(48, 59, 2),
(49, 60, 2),
(50, 61, 2),
(51, 62, 2),
(52, 63, 2),
(53, 64, 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `id_role` int(11) DEFAULT 2,
  `id_status` int(11) NOT NULL DEFAULT 2,
  `en_user` varchar(75) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `email` varchar(75) DEFAULT NULL,
  `password` varchar(75) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id_user`, `id_role`, `id_status`, `en_user`, `username`, `email`, `password`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '', 'admin', 'admin@gmail.com', '$2y$10$//KMATh3ibPoI3nHFp7x/u7vnAbo2WyUgmI4x0CVVrH8ajFhMvbjG', '2023-03-27 15:14:01', '2023-03-27 15:14:01'),
(4, 2, 1, '1816629146', 'ar.code_', 'arlan270899@gmail.com', '$2y$10$fwOg.Gr2obI8BgM7tgylme.FGnq/k8ui2ORKB7I37IYqyXf8mVRmu', '2023-06-20 08:35:01', '2023-06-20 08:35:01'),
(7, 2, 1, '471492458', 'Ronal', 'ferdychanellay@gmail.com', '$2y$10$vy5YYPHzHNlz7foghf6J2.Z7Gh9SByMYLGpgaRhkq4oWhID3Vo4H6', '2023-07-03 09:11:22', '2023-07-03 09:11:22');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users_role`
--

CREATE TABLE `users_role` (
  `id_role` int(11) NOT NULL,
  `role` varchar(35) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `users_role`
--

INSERT INTO `users_role` (`id_role`, `role`) VALUES
(1, 'Admin'),
(2, 'Mahasiswa');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `kelas`
--
ALTER TABLE `kelas`
  ADD PRIMARY KEY (`id_kelas`);

--
-- Indeks untuk tabel `klasifikasi`
--
ALTER TABLE `klasifikasi`
  ADD PRIMARY KEY (`id_klasifikasi`),
  ADD KEY `id_testing` (`id_testing`);

--
-- Indeks untuk tabel `skripsi`
--
ALTER TABLE `skripsi`
  ADD PRIMARY KEY (`id_skripsi`);

--
-- Indeks untuk tabel `testing`
--
ALTER TABLE `testing`
  ADD PRIMARY KEY (`id_testing`),
  ADD KEY `id_skripsi` (`id_skripsi`),
  ADD KEY `id_kelas` (`id_kelas`);

--
-- Indeks untuk tabel `training`
--
ALTER TABLE `training`
  ADD PRIMARY KEY (`id_training`),
  ADD KEY `id_skripsi` (`id_skripsi`),
  ADD KEY `id_kelas` (`id_kelas`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`),
  ADD KEY `id_role` (`id_role`);

--
-- Indeks untuk tabel `users_role`
--
ALTER TABLE `users_role`
  ADD PRIMARY KEY (`id_role`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `kelas`
--
ALTER TABLE `kelas`
  MODIFY `id_kelas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `klasifikasi`
--
ALTER TABLE `klasifikasi`
  MODIFY `id_klasifikasi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=380;

--
-- AUTO_INCREMENT untuk tabel `skripsi`
--
ALTER TABLE `skripsi`
  MODIFY `id_skripsi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT untuk tabel `testing`
--
ALTER TABLE `testing`
  MODIFY `id_testing` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT untuk tabel `training`
--
ALTER TABLE `training`
  MODIFY `id_training` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `users_role`
--
ALTER TABLE `users_role`
  MODIFY `id_role` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `klasifikasi`
--
ALTER TABLE `klasifikasi`
  ADD CONSTRAINT `klasifikasi_ibfk_1` FOREIGN KEY (`id_testing`) REFERENCES `testing` (`id_testing`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `testing`
--
ALTER TABLE `testing`
  ADD CONSTRAINT `testing_ibfk_1` FOREIGN KEY (`id_skripsi`) REFERENCES `skripsi` (`id_skripsi`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `testing_ibfk_2` FOREIGN KEY (`id_kelas`) REFERENCES `kelas` (`id_kelas`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `training`
--
ALTER TABLE `training`
  ADD CONSTRAINT `training_ibfk_1` FOREIGN KEY (`id_skripsi`) REFERENCES `skripsi` (`id_skripsi`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `training_ibfk_2` FOREIGN KEY (`id_kelas`) REFERENCES `kelas` (`id_kelas`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`id_role`) REFERENCES `users_role` (`id_role`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
