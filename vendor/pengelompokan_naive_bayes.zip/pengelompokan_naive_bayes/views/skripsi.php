<?php require_once("../controller/script.php");
require_once("redirect.php");
$_SESSION["page-name"] = "Skripsi";
$_SESSION["page-url"] = "skripsi";
?>

<!DOCTYPE html>
<html lang="en">

<head><?php require_once("../resources/dash-header.php") ?></head>

<body>
  <?php if (isset($_SESSION["message-success"])) { ?>
    <div class="message-success" data-message-success="<?= $_SESSION["message-success"] ?>"></div>
  <?php }
  if (isset($_SESSION["message-info"])) { ?>
    <div class="message-info" data-message-info="<?= $_SESSION["message-info"] ?>"></div>
  <?php }
  if (isset($_SESSION["message-warning"])) { ?>
    <div class="message-warning" data-message-warning="<?= $_SESSION["message-warning"] ?>"></div>
  <?php }
  if (isset($_SESSION["message-danger"])) { ?>
    <div class="message-danger" data-message-danger="<?= $_SESSION["message-danger"] ?>"></div>
  <?php } ?>
  <div class="container-scroller">
    <?php require_once("../resources/dash-topbar.php") ?>
    <div class="container-fluid page-body-wrapper">
      <?php require_once("../resources/dash-sidebar.php") ?>
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-sm-12">
              <div class="home-tab">
                <div class="d-sm-flex align-items-center justify-content-between border-bottom">
                  <h2>Skripsi</h2>
                  <div>
                    <div class="btn-wrapper">
                      <a href="#" class="btn btn-primary text-white me-0" data-bs-toggle="modal" data-bs-target="#tambah"><i class="bi bi-plus-lg"></i> Tambah</a>
                      <div class="modal fade" id="tambah" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header border-bottom-0 shadow">
                              <h5 class="modal-title" id="exampleModalLabel">Tambah Data Skripsi</h5>
                              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <form action="" method="post">
                              <div class="modal-body">
                                <div class="mb-3">
                                  <label for="nama_mahasiswa" class="form-label">Nama Mahasiswa</label>
                                  <input type="text" name="nama_mahasiswa" value="<?php if (isset($_POST['nama_mahasiswa'])) {
                                                                          echo $_POST['nama_mahasiswa'];
                                                                        } ?>" class="form-control" id="nama_mahasiswa" placeholder="Nama Mahasiswa" required>
                                </div>
                                
                                <div class="mb-3">
                                  <label for="NIM" class="form-label">NIM</label>
                                   <input type="text" name="NIM" value="<?php if (isset($_POST['NIM'])) {
                                                                            echo $_POST['NIM'];
                                                                          } ?>" class="form-control" id="NIM" placeholder="NIM" required>
                                </div>
                                <div class="mb-3">
                                  <label for="judul_skripsi" class="form-label">Judul Skripsi</label>
                                  <input type="text" name="judul_skripsi" value="<?php if (isset($_POST['judul_skripsi'])) {
                                                                            echo $_POST['judul_skripsi'];
                                                                          } ?>" class="form-control" id="judul_skripsi" placeholder="Judul Skripsi" required>
                                </div>
                                <div class="mb-3">
                                  <label for="abstrak_skripsi" class="form-label">Abstrak</label>
                                  <textarea name="abstrak_skripsi" value="<?php if (isset($_POST['abstrak_skripsi'])) {
                                                                            echo $_POST['abstrak_skripsi'];
                                                                          } ?>" class="form-control" id="abstrak_skripsi" placeholder="Abstrak Skripsi" required></textarea>
                                  
                                </div>
                                <div class="mb-3">
                                  <label for="Pembimbing" class="form-label">Pembimbing</label>
                                  <input type="text" name="Pembimbing" value="<?php if (isset($_POST['Pembimbing'])) {
                                                                            echo $_POST['Pembimbing'];
                                                                          } ?>" class="form-control" id="Pembimbing" placeholder="Pembimbing" required>
                                </div>
                                <div class="mb-3">
                                  <label for="Penguji" class="form-label">Penguji</label>
                                  <input type="text" name="Penguji" value="<?php if (isset($_POST['Penguji'])) {
                                                                            echo $_POST['Penguji'];
                                                                          } ?>" class="form-control" id="Penguji" placeholder="Penguji" required>
                                </div>
                                <div class="mb-3">
                                  <label for="Tahun" class="form-label">Tahun</label>
                                  <input type="text" name="Tahun" value="<?php if (isset($_POST['Tahun'])) {
                                                                            echo $_POST['Tahun'];
                                                                          } ?>" class="form-control" id="Tahun" placeholder="Tahun" required>
                                </div>
                                <div class="mb-3">
                                  <label for="kategori" class="form-label">Kategori Topik</label>
                                 <select name="id_kategori" class="form-select" aria-label="Default select example" required>
                                  <option selected value="">Kategori Topik</option>
                                  <?php foreach ($kategori as $data_k) : ?>
                                    <option value="<?= $data_k['id_kategori'] ?>"><?= $data_k['nama_kategori'] ?></option>
                                    <?php endforeach; ?>
                                  </select>




                                </div>
                              </div>
                              <div class="modal-footer border-top-0 justify-content-center">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                <button type="submit" name="tambah-skripsi" class="btn btn-primary text-white">Tambah</button>
                              </div>
                            </form>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="data-main">
                  <div class="table-responsive mt-3">
                    <table class="display table table-bordered table-striped table-sm" id="datatable">
                      <thead>
                        <tr>
                          <th class="text-center">Nama Mahasiswa</th>
                          <th class="text-center">NIM</th>
                          <th class="text-center">Judul Skripsi</th>
                          <th class="text-center">Abstrak</th>
                          <th class="text-center">Pembimbing</th>
                          <th class="text-center">Penguji</th>
                           <th class="text-center">Tahun</th>
                            <th class="text-center">Kategori Topik</th>
                          <th class="text-center">Aksi</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php if (mysqli_num_rows($skripsi) > 0) {
                          while ($row = mysqli_fetch_assoc($skripsi)) { ?>
                            <tr>
                              <td><?= $row['nama_mahasiswa'] ?></td>
                              <td><?= $row['NIM'] ?></td>
                               <td><?= $row['judul_skripsi'] ?></td>
                                <td><?= $row['abstrak_skripsi'] ?></td>
                                <td><?= $row['Pembimbing'] ?></td>
                                <td><?= $row['Penguji'] ?></td>
                                 <td><?= $row['Tahun'] ?></td>
                                  <td><?= $row['nama_kategori'] ?></td>


                             
                            
                              <td class="text-center">
                               
                                <a class="btn btn-warning p-2 text-white" class="btn btn-danger p-2 text-white" data-bs-toggle="modal" data-bs-target="#ubah<?= $row['id_skripsi'] ?>"><i class="bi bi-pencil-square"></i> Ubah</a>
                                <div class="modal fade" id="ubah<?= $row['id_skripsi'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                  <div class="modal-dialog">
                                    <div class="modal-content">
                                      <div class="modal-header border-bottom-0 shadow">
                                        <h5 class="modal-title" id="exampleModalLabel"><?= $row['nama_mahasiswa'] ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                      </div>
                                      <form action="" method="post">
                                        <input type="hidden" name="id-skripsi" value="<?= $row['id_skripsi'] ?>">
                                        <div class="modal-body">
                                          <div class="mb-3">
                                            <label for="nama-mahasiswa" class="form-label">Nama Mahasiswa</label>
                                            <input type="text" name="nama-mahasiswa" value="<?php if (isset($_POST['nama_mahasiswa'])) {
                                                                                    echo $_POST['nama-mahasiswa'];
                                                                                  } else {
                                                                                    echo $row['nama_mahasiswa'];
                                                                                  } ?>" class="form-control" id="nama-mahasiswa" placeholder="Nama Mahasiswa" required>
                                          </div>
                                          <div class="mb-3">
                                            <label for="nim" class="form-label">NIM</label>
                                            <input type="text" name="nim" value="<?php if (isset($_POST['NIM'])) {
                                                                                    echo $_POST['nim'];
                                                                                  } else {
                                                                                    echo $row['NIM'];
                                                                                  } ?>" class="form-control" id="nim" placeholder="NIM" required>
                                          </div>
                                          <div class="mb-3">
                                            <label for="judul-skripsi" class="form-label">Judul Skripsi</label>
                                            <input type="text" name="judul-skripsi" value="<?php if (isset($_POST['judul_skripsi'])) {
                                                                                    echo $_POST['judul-skripsi'];
                                                                                  } else {
                                                                                    echo $row['judul_skripsi'];
                                                                                  } ?>" class="form-control" id="judul-skripsi" placeholder="Judul Skripsi" required>
                                          </div>
                                           <div class="mb-3">
                                            <label for="abstrak-skripsi" class="form-label">Abstrak Skripsi</label>
                                            <input type="text" name="abstrak-skripsi" value="<?php if (isset($_POST['abstrak_skripsi'])) {
                                                                                    echo $_POST['abstrak-skripsi'];
                                                                                  } else {
                                                                                    echo $row['abstrak_skripsi'];
                                                                                  } ?>" class="form-control" id="abstrak-skripsi" placeholder="Abstrak Skripsi" required>
                                          </div>
                                         

                                           <div class="mb-3">
                                            <label for="pembimbing" class="form-label">Pembimbing</label>
                                            <input type="text" name="pembimbing" value="<?php if (isset($_POST['Pembimbing'])) {
                                                                                    echo $_POST['pembimbing'];
                                                                                  } else {
                                                                                    echo $row['Pembimbing'];
                                                                                  } ?>" class="form-control" id="pembimbing" placeholder="Pembimbing" required>
                                          </div>

                                           <div class="mb-3">
                                            <label for="penguji" class="form-label">Penguji</label>
                                            <input type="text" name="penguji" value="<?php if (isset($_POST['Penguji'])) {
                                                                                    echo $_POST['penguji'];
                                                                                  } else {
                                                                                    echo $row['Penguji'];
                                                                                  } ?>" class="form-control" id="penguji" placeholder="Penguji" required>
                                          </div>
                                          
                                          <div class="mb-3">
                                            <label for="tahun" class="form-label">Tahun</label>
                                            <input type="text" name="tahun" value="<?php if (isset($_POST['Tahun'])) {
                                                                                      echo $_POST['tahun'];
                                                                                    } else {
                                                                                      echo $row['Tahun'];
                                                                                    } ?>" class="form-control" id="tahun" placeholder="Tahun" required>
                                          </div>
                                           <div class="mb-3">
                                            <label for="kategori-topik" class="form-label">Kategori Topik</label>
                                            <input type="text" name="kategori-topik" value="<?php if (isset($_POST['kategori_topik'])) {
                                                                                      echo $_POST['kategori-topik'];
                                                                                    } else {
                                                                                      echo $row['kategori_topik'];
                                                                                    } ?>" class="form-control" id="kategori-topik" placeholder="Kategori Topik" required>
                                          </div>
                                        </div>
                                        <div class="modal-footer justify-content-center border-top-0">
                                          <input type="hidden" name="id-skripsi" value="<?= $row["id_skripsi"] ?>">
                                            <input type="hidden" name="namaOld" value="<?= $row["nama_mahasiswa"] ?>">
                                          <button type="button" class="btn btn-secondary p-2" data-bs-dismiss="modal">Batal</button>
                                          <button type="submit" name="ubah-skripsi" class="btn btn-warning p-2 text-white">Ubah</button>
                                        </div>
                                      </form>
                                    </div>
                                  </div>
                                </div>
                                <a class="btn btn-danger p-2 text-white" data-bs-toggle="modal" data-bs-target="#hapus<?= $row['id_skripsi'] ?>"><i class="bi bi-trash3"></i> Hapus</a>
                                <div class="modal fade" id="hapus<?= $row['id_skripsi'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                  <div class="modal-dialog">
                                    <div class="modal-content">
                                      <div class="modal-header border-bottom-0 shadow">
                                        <h5 class="modal-title" id="exampleModalLabel"><?= $row['skripsi'] ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                      </div>
                                      <form action="" method="post">
                                        <input type="hidden" name="id-skripsi" value="<?= $row['id_skripsi'] ?>">
                                        <div class="modal-body">
                                          <p>Anda yakin ingin menghapus skripsi ini?</p>
                                        </div>
                                        <div class="modal-footer justify-content-center border-top-0">
                                          <button type="button" class="btn btn-secondary p-2" data-bs-dismiss="modal">Batal</button>
                                          <button type="submit" name="hapus-skripsi" class="btn btn-danger p-2 text-white">Hapus</button>
                                        </div>
                                      </form>
                                    </div>
                                  </div>
                                </div>
                              </td>
                            </tr>
                        <?php }
                        } ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <?php require_once("../resources/dash-footer.php") ?>
</body>

</html>