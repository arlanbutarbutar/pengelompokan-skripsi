<?php require_once("../controller/script.php");
require_once("redirect.php");
$_SESSION["page-name"] = "Tambah Kriteria";
$_SESSION["page-url"] = "tambahKriteria";
$id_warga = $_GET['id_warga'];
$query = mysqli_query($conn, "SELECT * FROM warga WHERE id_warga='$id_warga'");
$data = mysqli_fetch_assoc($query);
?>

<!DOCTYPE html>
<html lang="en">

<head><?php require_once("../resources/dash-header.php") ?></head>

<body>
  <?php if (isset($_SESSION["message-success"])) { ?>
    <div class="message-success" data-message-success="<?= $_SESSION["message-success"] ?>"></div>
  <?php }
  if (isset($_SESSION["message-info"])) { ?>
    <div class="message-info" data-message-info="<?= $_SESSION["message-info"] ?>"></div>
  <?php }
  if (isset($_SESSION["message-warning"])) { ?>
    <div class="message-warning" data-message-warning="<?= $_SESSION["message-warning"] ?>"></div>
  <?php }
  if (isset($_SESSION["message-danger"])) { ?>
    <div class="message-danger" data-message-danger="<?= $_SESSION["message-danger"] ?>"></div>
  <?php } ?>
  <div class="container-scroller">
    <?php require_once("../resources/dash-topbar.php") ?>
    <div class="container-fluid page-body-wrapper">
      <?php require_once("../resources/dash-sidebar.php") ?>
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-sm-12">
              <div class="home-tab">
                <div class="d-sm-flex align-items-center justify-content-between border-bottom">
                  <h2>Bantuan BLT</h2>
                </div>
                <div class="data-main">
                  <p>
                    <center>
                      <h2>Persyaratan Pemenuahan Kriteria <h2>
                    </center>
                  </p>
                  <br>
                  <form role="form" method="post">
                    <div class="form-group">
                      <label>Nama Calon</label>
                      <input class="form-control" value="<?= $data['nama']; ?>" readonly>
                      <input type="hidden" name="id_warga" value="<?= $data['id_warga']; ?>">
                    </div>
                    <div class="form-group">
                      <label>Pendidikan</label>
                      <select class="custom-select form-control" name="pendidikan">
                        <option value="">Pilih Pendidikan</option>
                        <?php
                        $query1 = "SELECT * FROM sub_kriteria where id_kriteria='9' order by id_sub_kriteria asc";
                        $pendidikan = mysqli_query($conn, $query1);
                        while ($d = mysqli_fetch_assoc($pendidikan)) { ?>
                          <option value="<?= $d['sub_kriteria'] ?>"><?= $d['sub_kriteria']; ?>
                          </option>
                        <?php } ?>
                      </select>
                    </div>
                    <div class="form-group">
                      <label>Pekerjaan</label>
                      <select class="custom-select form-control" name="pekerjaan">
                        <option value="">Pilih Pekerjaan</option>
                        <?php
                        $query2 = "SELECT * FROM sub_kriteria where id_kriteria='10' order by id_sub_kriteria asc";
                        $pekerjaan = mysqli_query($conn, $query2);
                        while ($d = mysqli_fetch_assoc($pekerjaan)) { ?>
                          <option value="<?= $d['sub_kriteria'] ?>"><?= $d['sub_kriteria']; ?>
                          </option>
                        <?php } ?>
                      </select>
                    </div>
                    <div class="form-group">
                      <label>Penghasilan</label>
                      <select class="custom-select form-control" name="penghasilan">
                        <option selected disabled>Pilih Penghasilan</option>
                        <?php
                        $query3 = "SELECT * FROM sub_kriteria where id_kriteria='11' order by id_sub_kriteria asc";
                        $penghasilan = mysqli_query($conn, $query3);
                        while ($d = mysqli_fetch_assoc($penghasilan)) { ?>
                          <option value="<?= $d['sub_kriteria'] ?>"><?= $d['sub_kriteria']; ?>
                          <?php } ?>
                      </select>
                    </div>
                    <div class="form-group">
                      <label>Kondisi Rumah</label>
                      <select class="custom-select form-control" name="kondisi_rumah">
                        <option selected disabled>Pilih Kondisi Rumah</option>
                        <?php
                        $query4 = "SELECT * FROM sub_kriteria where id_kriteria='12' order by id_sub_kriteria asc";
                        $kondisi_rumah = mysqli_query($conn, $query4);
                        while ($d = mysqli_fetch_assoc($kondisi_rumah)) { ?>
                          <option value="<?= $d['sub_kriteria'] ?>"><?= $d['sub_kriteria']; ?>
                          <?php } ?>
                      </select>
                    </div>
                    <div class="form-group">
                      <label>Kapasitas WC</label>
                      <select class="custom-select form-control" name="kapasitas_wc">
                        <option selected disabled>Pilih Kapasitas WC</option>
                        <?php
                        $query5 = "SELECT * FROM sub_kriteria where id_kriteria='13' order by id_sub_kriteria asc";
                        $kapasitas_wc = mysqli_query($conn, $query5);
                        while ($d = mysqli_fetch_assoc($kapasitas_wc)) { ?>
                          <option value="<?= $d['sub_kriteria'] ?>"><?= $d['sub_kriteria']; ?>
                          <?php } ?>
                      </select>
                    </div>
                    <div class="form-group">
                      <label>Kapasitas Listrik</label>
                      <select class="custom-select form-control" name="kapasitas_listrik">
                        <option selected disabled>Pilih Kapasitas Listrik</option>
                        <?php
                        $query6 = "SELECT * FROM sub_kriteria where id_kriteria='14' order by id_sub_kriteria asc";
                        $kapasitas_listrik = mysqli_query($conn, $query6);
                        while ($d = mysqli_fetch_assoc($kapasitas_listrik)) { ?>
                          <option value="<?= $d['sub_kriteria'] ?>"><?= $d['sub_kriteria']; ?>
                          <?php } ?>
                      </select>
                    </div>
                    <div class="form-group">
                      <label>Bahan Bakar</label>
                      <select class="custom-select form-control" name="bahan_bakar">
                        <option selected disabled>Pilih Bahan Bakar</option>
                        <?php
                        $query7 = "SELECT * FROM sub_kriteria where id_kriteria='15' order by id_sub_kriteria asc";
                        $bahan_bakar = mysqli_query($conn, $query7);
                        while ($d = mysqli_fetch_assoc($bahan_bakar)) { ?>
                          <option value="<?= $d['sub_kriteria'] ?>"><?= $d['sub_kriteria']; ?>
                          <?php } ?>
                      </select>
                    </div>
                    <div class="form-group">
                      <label>Jumlah Tanggungan</label>
                      <select class="custom-select form-control" name="jumlah_tanggungan">
                        <option selected disabled>Pilih Jumlah Tanggungan</option>
                        <?php
                        $query8 = "SELECT * FROM sub_kriteria where id_kriteria='16' order by id_sub_kriteria asc";
                        $jumlah_tanggungan = mysqli_query($conn, $query8);
                        while ($d = mysqli_fetch_assoc($jumlah_tanggungan)) { ?>
                          <option value="<?= $d['sub_kriteria'] ?>"><?= $d['sub_kriteria']; ?>
                          <?php } ?>
                      </select>
                    </div>
                    <div class="form-group">
                      <label>Domisili</label>
                      <select class="custom-select form-control" name="domisili">
                        <option selected disabled>Pilih Domisili</option>
                        <?php
                        $query9 = "SELECT * FROM sub_kriteria where id_kriteria='17' order by id_sub_kriteria asc";
                        $domisili   = mysqli_query($conn, $query9);
                        while ($d = mysqli_fetch_assoc($domisili)) { ?>
                          <option value="<?= $d['sub_kriteria'] ?>"><?= $d['sub_kriteria']; ?>
                          <?php } ?>
                      </select>
                    </div>
                    <button type="submit" name="tambah-syarat" class="btn btn-primary pull-right">Simpan</button>
                    <a href="../index.php" class="btn btn-success pull-right" style="margin-right:1%;">Batal</a>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
        <?php require_once("../resources/dash-footer.php") ?>
</body>

</html>