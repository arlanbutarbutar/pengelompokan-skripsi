<?php require_once("../controller/script.php");
require_once("../controller/db_connect.php");
require_once("redirect.php");
$_SESSION["page-name"] = "Penilaian";
$_SESSION["page-url"] = "penilaian";
?>

<!DOCTYPE html>
<html lang="en">

<head><?php require_once("../resources/dash-header.php") ?></head>

<body>
  <?php if (isset($_SESSION["message-success"])) { ?>
    <div class="message-success" data-message-success="<?= $_SESSION["message-success"] ?>"></div>
  <?php }
  if (isset($_SESSION["message-info"])) { ?>
    <div class="message-info" data-message-info="<?= $_SESSION["message-info"] ?>"></div>
  <?php }
  if (isset($_SESSION["message-warning"])) { ?>
    <div class="message-warning" data-message-warning="<?= $_SESSION["message-warning"] ?>"></div>
  <?php }
  if (isset($_SESSION["message-danger"])) { ?>
    <div class="message-danger" data-message-danger="<?= $_SESSION["message-danger"] ?>"></div>
  <?php } ?>
  <div class="container-scroller">
    <?php require_once("../resources/dash-topbar.php") ?>
    <div class="container-fluid page-body-wrapper">
      <?php require_once("../resources/dash-sidebar.php") ?>
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-sm-12">
              <div class="home-tab">
                <div class="d-sm-flex align-items-center justify-content-between border-bottom">
                  <h2>Penilaian</h2>
                </div>
                <div class="data-main">
                  <div class="table-responsive mt-3">
                    <table class="display table table-bordered table-striped table-sm" id="datatable">
                      <thead>
                        <tr>
                          <th>
                            No
                          </th>
                          <th class="text-center">
                            Nama Warga
                          </th>
                          <th class="text-center">
                            Pendidikan
                          </th>
                          <th class="text-center">
                            Pekerjaan
                          </th>
                          <th class="text-center">
                            Penghasilan
                          </th>
                          <th class="text-center">
                            Kondisi Rumah
                          </th>
                          <th class="text-center">
                            Kapasitas WC
                          </th>
                          <th class="text-center">
                            Kapasitas Listrik
                          </th>
                          <th class="text-center">
                            Bahan Bakar
                          </th>
                          <th class="text-center">
                            Jumlah Tanggungan
                          </th>
                          <th class="text-center">
                            Domisili
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                        $cekAlternatif = mysqli_query($conn, "SELECT * FROM alternatif JOIN warga ON alternatif.id_warga = warga.id_warga ORDER BY alternatif.id_alternatif DESC");
                        $no = 1;
                        while ($dataAlternatif = mysqli_fetch_assoc($cekAlternatif)) {
                          $id_alternatif[] = $dataAlternatif['id_alternatif'];
                        }
                        if (mysqli_num_rows($alternatif) > 0) {
                          while ($row = mysqli_fetch_assoc($alternatif)) { ?>
                            <tr>
                              <td><?= $no++; ?></td>
                              <td><?= $row['nama'] ?></td>
                              <td><?= $row['pendidikan'] ?></td>
                              <td><?= $row['pekerjaan'] ?></td>
                              <td><?= $row['penghasilan'] ?></td>
                              <td><?= $row['kondisi_rumah'] ?></td>
                              <td><?= $row['kapasitas_wc'] ?></td>
                              <td><?= $row['kapasitas_listrik'] ?></td>
                              <td><?= $row['bahan_bakar'] ?></td>
                              <td><?= $row['jumlah_tanggungan'] ?></td>
                              <td><?= $row['domisili'] ?></td>
                              <td class="text-center">
                                <a class="btn btn-warning p-2 text-white" class="btn btn-danger p-2 text-white" data-bs-toggle="modal" data-bs-target="#ubah<?= $row['id_alternatif'] ?>"><i class="bi bi-pencil-square"></i> Ubah</a>
                                <div class="modal fade" id="ubah<?= $row['id_alternatif'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                  <div class="modal-dialog">
                                    <div class="modal-content">
                                      <div class="modal-header border-bottom-0 shadow">
                                        <h5 class="modal-title" id="exampleModalLabel"><?= $row['nama'] ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                      </div>
                                      <form action="" method="post">
                                        <input type="hidden" name="id-alternatif" value="<?= $row['id_alternatif'] ?>">
                                        <div class="modal-body">
                                          <div class="mb-3">
                                            <label for="pendidikan" class="form-label">Pendidikan</label>
                                            <select class="custom-select form-control" name="pendidikan">
                                              <option value="<?= $row['pendidikan'] ?>"><?= $row['pendidikan'] ?></option>
                                              <?php $pendidikan = $row['pendidikan'];
                                              $query1 = "SELECT * FROM sub_kriteria where id_kriteria='9' and sub_kriteria!='$pendidikan' order by id_sub_kriteria asc";
                                              $pendidikan = mysqli_query($conn, $query1);
                                              while ($d = mysqli_fetch_assoc($pendidikan)) { ?>
                                                <option value="<?= $d['sub_kriteria'] ?>"><?= $d['sub_kriteria']; ?>
                                                </option>
                                              <?php } ?>
                                            </select>
                                          </div>
                                          <div class="mb-3">
                                            <label for="pekerjaan" class="form-label">Pekerjaan</label>
                                            <select class="custom-select form-control" name="pekerjaan">
                                              <option value="<?= $row['pekerjaan'] ?>"><?= $row['pekerjaan'] ?></option>
                                              <?php $pekerjaan = $row['pekerjaan'];
                                              $query2 = "SELECT * FROM sub_kriteria where id_kriteria='10' and sub_kriteria!='$pekerjaan' order by id_sub_kriteria asc";
                                              $pekerjaan = mysqli_query($conn, $query2);
                                              while ($d = mysqli_fetch_assoc($pekerjaan)) { ?>
                                                <option value="<?= $d['sub_kriteria'] ?>"><?= $d['sub_kriteria']; ?>

                                                </option>
                                              <?php } ?>
                                            </select>
                                          </div>
                                          <div class="mb-3">
                                            <label for="penghasilan" class="form-label">Penghasilan</label>
                                            <select class="custom-select form-control" name="penghasilan">
                                              <option selected value="<?= $row['penghasilan'] ?>"><?= $row['penghasilan'] ?></option>
                                              <?php $penghasilan = $row['penghasilan'];
                                              $query3 = "SELECT * FROM sub_kriteria where id_kriteria='11' and sub_kriteria!='$penghasilan' order by id_sub_kriteria asc";
                                              $penghasilan = mysqli_query($conn, $query3);
                                              while ($d = mysqli_fetch_assoc($penghasilan)) { ?>
                                                <option value="<?= $d['sub_kriteria'] ?>"><?= $d['sub_kriteria']; ?>
                                                <?php } ?>
                                            </select>
                                          </div>
                                          <div class="mb-3">
                                            <label for="kondisi_rumah" class="form-label">Kondisi Rumah</label>
                                            <select class="custom-select form-control" name="kondisi_rumah">
                                              <option selected value="<?= $row['kondisi_rumah'] ?>"><?= $row['kondisi_rumah'] ?></option>
                                              <?php $kondisi_rumah = $row['kondisi_rumah'];
                                              $query4 = "SELECT * FROM sub_kriteria where id_kriteria='12' and sub_kriteria!='$kondisi_rumah' order by id_sub_kriteria asc";
                                              $kondisi_rumah = mysqli_query($conn, $query4);
                                              while ($d = mysqli_fetch_assoc($kondisi_rumah)) { ?>
                                                <option value="<?= $d['sub_kriteria'] ?>"><?= $d['sub_kriteria']; ?>
                                                <?php } ?>
                                            </select>
                                          </div>
                                          <div class="mb-3">
                                            <label for="kapasitas_wc" class="form-label">Kapasitas WC</label>
                                            <select class="custom-select form-control" name="kapasitas_wc">
                                              <option selected value="<?= $row['kapasitas_wc'] ?>"><?= $row['kapasitas_wc'] ?></option>
                                              <?php $kapasitas_wc = $row['kapasitas_wc'];
                                              $query5 = "SELECT * FROM sub_kriteria where id_kriteria='13' and sub_kriteria!='$kapasitas_wc' order by id_sub_kriteria asc";
                                              $kapasitas_wc = mysqli_query($conn, $query5);
                                              while ($d = mysqli_fetch_assoc($kapasitas_wc)) { ?>
                                                <option value="<?= $d['sub_kriteria'] ?>"><?= $d['sub_kriteria']; ?>
                                                <?php } ?>
                                            </select>
                                          </div>
                                          <div class="mb-3">
                                            <label for="kapasitas_listrik" class="form-label">Kapasitas Listrik</label>
                                            <select class="custom-select form-control" name="kapasitas_listrik">
                                              <option selected value="<?= $row['kapasitas_listrik'] ?>"><?= $row['kapasitas_listrik'] ?></option>
                                              <?php $kapasitas_listrik = $row['kapasitas_listrik'];
                                              $query6 = "SELECT * FROM sub_kriteria where id_kriteria='14' and sub_kriteria!='$kapasitas_listrik' order by id_sub_kriteria asc";
                                              $kapasitas_listrik = mysqli_query($conn, $query6);
                                              while ($d = mysqli_fetch_assoc($kapasitas_listrik)) { ?>
                                                <option value="<?= $d['sub_kriteria'] ?>"><?= $d['sub_kriteria']; ?>
                                                <?php } ?>
                                            </select>
                                          </div>
                                          <div class="mb-3">
                                            <label for="bahan_bakar" class="form-label">Bahan Bakar</label>
                                            <select class="custom-select form-control" name="bahan_bakar">
                                              <option selected value="<?= $row['bahan_bakar'] ?>"><?= $row['bahan_bakar'] ?></option>
                                              <?php $bahan_bakar = $row['bahan_bakar'];
                                              $query7 = "SELECT * FROM sub_kriteria where id_kriteria='15' and sub_kriteria!='$bahan_bakar' order by id_sub_kriteria asc";
                                              $bahan_bakar = mysqli_query($conn, $query7);
                                              while ($d = mysqli_fetch_assoc($bahan_bakar)) { ?>
                                                <option value="<?= $d['sub_kriteria'] ?>"><?= $d['sub_kriteria']; ?>
                                                <?php } ?>
                                            </select>
                                          </div>
                                          <div class="mb-3">
                                            <label for="jumlah_tanggungan" class="form-label">Jumlah Tanggungan</label>
                                            <select class="custom-select form-control" name="jumlah_tanggungan">
                                              <option selected value="<?= $row['jumlah_tanggungan'] ?>"><?= $row['jumlah_tanggungan'] ?></option>
                                              <?php $jumlah_tanggungan = $row['jumlah_tanggungan'];
                                              $query8 = "SELECT * FROM sub_kriteria where id_kriteria='16' and sub_kriteria!='$jumlah_tanggungan' order by id_sub_kriteria asc";
                                              $jumlah_tanggungan = mysqli_query($conn, $query8);
                                              while ($d = mysqli_fetch_assoc($jumlah_tanggungan)) { ?>
                                                <option value="<?= $d['sub_kriteria'] ?>"><?= $d['sub_kriteria']; ?>
                                                <?php } ?>
                                            </select>
                                          </div>
                                          <div class="mb-3">
                                            <label for="domisili" class="form-label">Domisili</label>
                                            <select class="custom-select form-control" name="domisili">
                                              <option selected value="<?= $row['domisili'] ?>"><?= $row['domisili'] ?></option>
                                              <?php $domisili = $row['domisili'];
                                              $query9 = "SELECT * FROM sub_kriteria where id_kriteria='17' and sub_kriteria!='$domisili' order by id_sub_kriteria asc";
                                              $domisili = mysqli_query($conn, $query9);
                                              while ($d = mysqli_fetch_assoc($domisili)) { ?>
                                                <option value="<?= $d['sub_kriteria'] ?>"><?= $d['sub_kriteria']; ?>
                                                <?php } ?>
                                            </select>
                                          </div>
                                        </div>
                                        <div class="modal-footer justify-content-center border-top-0">
                                          <button type="button" class="btn btn-secondary p-2" data-bs-dismiss="modal">Batal</button>
                                          <button type="submit" name="ubah-alternatif" class="btn btn-warning p-2 text-white">Ubah</button>
                                        </div>
                                      </form>
                                    </div>
                                  </div>
                                </div>
                                <a class="btn btn-danger p-2 text-white" data-bs-toggle="modal" data-bs-target="#hapus<?= $row['id_alternatif'] ?>"><i class="bi bi-trash3"></i> Hapus</a>
                                <div class="modal fade" id="hapus<?= $row['id_alternatif'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                  <div class="modal-dialog">
                                    <div class="modal-content">
                                      <div class="modal-header border-bottom-0 shadow">
                                        <h5 class="modal-title" id="exampleModalLabel"><?= $row['alternatif'] ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                      </div>
                                      <form action="" method="post">
                                        <input type="hidden" name="id-alternatif" value="<?= $row['id_alternatif'] ?>">
                                        <input type="hidden" name="id-warga" value="<?= $row['id_warga'] ?>">
                                        <div class="modal-body">
                                          <p>Anda yakin ingin menghapus data warga ini?</p>
                                        </div>
                                        <div class="modal-footer justify-content-center border-top-0">
                                          <button type="button" class="btn btn-secondary p-2" data-bs-dismiss="modal">Batal</button>
                                          <button type="submit" name="hapus-alternatif" class="btn btn-danger p-2 text-white">Hapus</button>
                                        </div>
                                      </form>
                                    </div>
                                  </div>
                                </div>
                              </td>
                            </tr>
                        <?php }
                        } ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <?php require_once("../resources/dash-footer.php") ?>
</body>

</html>