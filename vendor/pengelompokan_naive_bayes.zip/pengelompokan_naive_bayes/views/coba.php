<?php

// String yang akan diuji
$data = "Aplikasi Mobile untuk Penjualan Barang Elektronik";

// Mencari kata "software" dalam string
if (strpos(strtolower($data), "software") !== false) {
  echo "Kategori: Software";
}

// Mencari kata "mobile" dalam string
if (strpos(strtolower($data), "mobile") !== false) {
  echo "Kategori: Mobile";
}

?>
