<?php require_once("../controller/script.php");
require_once("redirect.php");
$_SESSION["page-name"] = "Preprocessing";
$_SESSION["page-url"] = "preprocessing";
?>

<!DOCTYPE html>
<html lang="en">

<head><?php require_once("../resources/dash-header.php") ?></head>

<body>
  <?php if (isset($_SESSION["message-success"])) { ?>
    <div class="message-success" data-message-success="<?= $_SESSION["message-success"] ?>"></div>
  <?php }
  if (isset($_SESSION["message-info"])) { ?>
    <div class="message-info" data-message-info="<?= $_SESSION["message-info"] ?>"></div>
  <?php }
  if (isset($_SESSION["message-warning"])) { ?>
    <div class="message-warning" data-message-warning="<?= $_SESSION["message-warning"] ?>"></div>
  <?php }
  if (isset($_SESSION["message-danger"])) { ?>
    <div class="message-danger" data-message-danger="<?= $_SESSION["message-danger"] ?>"></div>
  <?php } ?>
  <div class="container-scroller">
    <?php require_once("../resources/dash-topbar.php") ?>
    <div class="container-fluid page-body-wrapper">
      <?php require_once("../resources/dash-sidebar.php") ?>
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-sm-12">
              <div class="home-tab">
                <div class="d-sm-flex align-items-center justify-content-between border-bottom">
                  <h2>Preprocessing Data</h2>
                </div>
                <div class="data-main">
                  <?php

                   $skripsi = array();
                  $data_skripsi= mysqli_query($conn, "SELECT * FROM skripsi WHERE id_skripsi");
                  foreach ($data_skripsi as $row) {
                    $skripsi[$row['id_skripsi']] = array(
                      'nama_mahasiswa' => $row['judul'],
                      'NIM' => $row['NIM'],
                      'judul_skripsi' => $row['judul_skripsi'],
                        'abstrak_skripsi' => $row['abstrak_skripsi'],
                          'Pembimbing' => $row['Pembimbing'],
                            'Penguji' => $row['Penguji'],
                              'Tahun' => $row['Tahun'],
                                'kategori_topik' => $row['kategori_topik'],
                    );
                  }
                  $jml_skripsi = count($skripsi);

                  // Menampilkan Data Skripsi
                  echo "<br>Data preprocessing<br>================================<br>";
                  echo "<table border='1'>";
                  echo "<tr>
                        <th>Nama Mahasiswa</th>
                        <th>NIM</th>
                        <th>Judul Skripsi</th>
                        <th>Abstrak</th>
                        <th>Pembimbing</th> 
                        <th>Penguji</th>
                        <th>Tahun</th>
                        <th>Kategori Topik</th> 


                  </tr>";
                  foreach ($data_skripsi as $id_skripsi => $data) {
                    echo "<tr>";
                    echo "<td>" . $data['nama_mahasiswa'] ." ". "</td>";
                    echo "<td>" . $data['NIM'] ." ". "</td>";
                    echo "<td>" . $data['judul_skripsi'] ." ". "</td>";
                    echo "<td>" . $data['abstrak_skripsi'] ." ". "</td>";
                    echo "<td>" . $data['Pembimbing']." " . "</td>";
                    echo "<td>" . $data['Penguji'] ." ". "</td>";
                    echo "<td>" . $data['Tahun'] ." ". "</td>";
                    echo "<td>" . $data['kategori_topik']." " . "</td>";
                   
                    echo "</tr>";
                  }
                  echo "</table>";

                  $query = "SELECT id_skripsi, judul_skripsi, abstrak_skripsi FROM skripsi";
                  $result = mysqli_query($conn, $query);
                  while ($row = mysqli_fetch_assoc($result)) {
                    $id = $row['id_skripsi'];
                    $judul = $row['judul_skripsi'];
                    $abstrak = $row['abstrak_skripsi'];
    // menghapus karakter non-alfanumerik
    $judul = preg_replace('/[^A-Za-z0-9]/', ' ', $judul);
    $abstrak = preg_replace('/[^A-Za-z0-9]/', ' ', $abstrak);

    $judul = preg_replace('/\s+/', ' ', $teks); // menghapus spasi berlebih
    $abstrak = preg_replace('/\s+/', ' ', $teks); // menghapus spasi berlebih

    // mengubah huruf menjadi lowercase
    $judul = strtolower($judul);
    $abstrak = strtolower($abstrak);

    // menghapus stopword
    $stopword = array('a', 'an', 'the', 'is', 'are', 'in', 'on', 'of', 'to');
    $judul = preg_replace('/\b('.implode('|', $stopword).')\b/', '', $judul);
    $abstrak = preg_replace('/\b('.implode('|', $stopword).')\b/', '', $abstrak);

    // simpan data hasil preprocessing ke tabel skripsi_preprocessed
    $query = "INSERT INTO skripsi_preprocessed (id_skripsi, judul, abstrak) 
              VALUES ('$id', '$judul', '$abstrak')";
    mysqli_query($conn, $query);
}
  






                  $skripsi_preprocessed = array();
                  $preprocessed= mysqli_query($conn, "SELECT * FROM skripsi, skripsi_preprocessed WHERE skripsi.id_skripsi = skripsi_preprocessed.id_skripsi");
                  foreach ($preprocessed as $row) {
                    $skripsi_preprocessed[$row['id_skripsi_preprocessed']] = array(
                       'nama_mahasiswa' => $row['nama_mahasiswa'],
                        'NIM' => $row['NIM'],
                      'judul' => $row['judul'],
                      'abstrak' => $row['abstrak'],
                      'kata_kunci' => $row['kata_kunci'],
                    );
                  }
                 


                  // Menampilkan Data hasil preprocessing
                  echo "<br>Data preprocessing<br>================================<br>";
                  echo "<table border='1'>";
                  echo "<tr><th>Judul</th><th>Abstrak</th><th>Kata Kunci</th></tr>";
                  foreach ($preprocessed as $id_skripsi_preprocessed => $data) {
                    echo "<tr>";
                     echo "<td>" . $data['nama_mahasiswa'] . "</td>";
                    echo "<td>" . $data['NIM'] . "</td>";
                    echo "<td>" . $data['judul'] . "</td>";
                    echo "<td>" . $data['abstrak'] . "</td>";
                    echo "<td>" . $data['kata_kunci'] . "</td>";
                    echo "</tr>";
                  }
                  echo "</table>";


// Ambil data skripsi yang sudah di-preprocessing dari database
$query = "SELECT * FROM skripsi_preprocessed";
$result = mysqli_query($conn, $query);
$skripsi = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Tentukan rasio training dan testing
$train_ratio = 0.8;
$test_ratio = 0.2;

// Hitung jumlah data training dan testing
$num_data = count($skripsi);
$num_train = (int)($train_ratio * $num_data);
$num_test = $num_data - $num_train;

// Acak urutan data
shuffle($skripsi);

// Pisahkan data menjadi data training dan data testing
$train_data = array_slice($skripsi, 0, $num_train);
$test_data = array_slice($skripsi, $num_train, $num_test);

// Simpan data training dan testing ke dalam tabel baru
foreach ($train_data as $data) {
    $id = $data['id_skripsi'];
    $judul = $data['judul'];
    $abstrak = $data['abstrak'];
    $kategori = $data['kategori_topik'];
    $query = "INSERT INTO skripsi_training (id_skripsi, judul, abstrak, kategori_topik) 
              VALUES ('$id', '$judul', '$abstrak', '$kategori')";
    mysqli_query($conn, $query);
}
foreach ($test_data as $data) {
    $id = $data['id_skripsi'];
    $judul = $data['judul'];
    $abstrak = $data['abstrak'];
    $kategori = $data['kategori_topik'];
    $query = "INSERT INTO skripsi_testing (id_skripsi, judul, abstrak, kategori_topik) 
              VALUES ('$id', '$judul', '$abstrak', '$kategori')";
    mysqli_query($conn, $query);
}

// query untuk mengambil data dari tabel skripsi_training
$query = "SELECT * FROM skripsi_training";
$result = mysqli_query($conn, $query);

// tampilkan data dalam tabel
echo "<table border='1'>
      <tr>
        <th>ID Skripsi</th>
        <th>Judul</th>
        <th>Abstrak</th>
        <th>Kategori Topik</th>
      </tr>";
while ($row = mysqli_fetch_assoc($result)) {
  echo "<tr>";
  echo "<td>".$row['id_skripsi']."</td>";
  echo "<td>".$row['judul']."</td>";
  echo "<td>".$row['abstrak']."</td>";
  echo "<td>".$row['kategori_topik']."</td>";
  echo "</tr>";
}
echo "</table>";

// query untuk mengambil data dari tabel skripsi_testing
$query = "SELECT * FROM skripsi_testing";
$result = mysqli_query($conn, $query);

// tampilkan data dalam tabel
echo "<table border='1'>
      <tr>
        <th>ID Skripsi</th>
        <th>Judul</th>
        <th>Abstrak</th>
        <th>Kategori Topik</th>
      </tr>";
while ($row = mysqli_fetch_assoc($result)) {
  echo "<tr>";
  echo "<td>".$row['id_skripsi']."</td>";
  echo "<td>".$row['judul']."</td>";
  echo "<td>".$row['abstrak']."</td>";
  echo "<td>".$row['kategori_topik']."</td>";
  echo "</tr>";
}
echo "</table>";





                  ?>

                </div>
              </div>
            </div>
          </div>
        </div>
        <?php require_once("../resources/dash-footer.php") ?>
</body>

</html>