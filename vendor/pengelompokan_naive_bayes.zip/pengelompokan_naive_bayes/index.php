<?php require_once("controller/script.php");
$_SESSION["page-name"] = "";
$_SESSION["page-url"] = "./";
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <?php require_once("resources/header.php") ?>
</head>

<body>
  <div class="container-xxl bg-white p-0">

    <!-- Navbar & Hero Start -->
    <?php require_once("resources/navbar.php") ?>
    <!-- Navbar & Hero End -->

    <!-- Footer Start -->
    <?php require_once("resources/footer.php") ?>
    <!-- Footer End -->
</body>

</html>