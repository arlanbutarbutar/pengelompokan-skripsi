<div class="container-fluid bg-primary text-light footer wow fadeIn" style="margin-top: -50px;" data-wow-delay="0.1s">
  <div class="container px-lg-5">
    <div class="copyright">
      <div class="row">
        <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
          Copyright © <?= date("Y") ?> <a style="cursor: pointer;" onclick="window.open('https://netmedia-framecode.com', '_blank')">Netmedia Framecode</a> . All rights reserved.

          <!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support. ***/-->
          Powered By Ferdy Chanel Daresurecao Lay
        </div>
        <div class="col-md-6 text-center text-md-end">
          <div class="footer-menu">
            <a href="./">Beranda</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- JavaScript Libraries -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= $baseURL ?>assets/lib/wow/wow.min.js"></script>
<script src="<?= $baseURL ?>assets/lib/easing/easing.min.js"></script>
<script src="<?= $baseURL ?>assets/lib/waypoints/waypoints.min.js"></script>
<script src="<?= $baseURL ?>assets/lib/owlcarousel/owl.carousel.min.js"></script>
<script src="<?= $baseURL ?>assets/lib/isotope/isotope.pkgd.min.js"></script>
<script src="<?= $baseURL ?>assets/lib/lightbox/js/lightbox.min.js"></script>

<!-- Template Javascript -->
<script src="<?= $baseURL ?>assets/js/main.js"></script>