<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title><?= $_SESSION["page-name"] ?> - Pengelompokan Skripsi</title>
<link rel="stylesheet" href="../assets/css/feather.css">
<link rel="stylesheet" href="../assets/mdi/css/materialdesignicons.min.css">
<link rel="stylesheet" href="../assets/ti-icons/css/themify-icons.css">
<link rel="stylesheet" href="../assets/typicons/typicons.css">
<link rel="stylesheet" href="../assets/css/simple-line-icons.css">
<link rel="stylesheet" href="../assets/css/vendor.bundle.base.css">
<link rel="stylesheet" href="../assets/css/style-dash.css">
<link rel="shortcut icon" href="../assets/images/logo.png" />
<script src="../assets/sweetalert/dist/sweetalert2.all.min.js"></script>
