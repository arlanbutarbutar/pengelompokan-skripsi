<?php
if (!isset($_SESSION["data-user"])) {
  function masuk($data)
  {
    global $conn;
    $email = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data["email"]))));
    $password = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data["password"]))));

    // check account
    $checkAccount = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
    if (mysqli_num_rows($checkAccount) == 0) {
      $_SESSION["message-danger"] = "Maaf, akun yang anda masukan belum terdaftar.";
      $_SESSION["time-message"] = time();
      return false;
    } else if (mysqli_num_rows($checkAccount) > 0) {
      $row = mysqli_fetch_assoc($checkAccount);
      if (password_verify($password, $row["password"])) {
        $_SESSION["data-user"] = [
          "id" => $row["id_user"],
          "role" => $row["id_role"],
          "email" => $row["email"],
          "username" => $row["username"],
        ];
      } else {
        $_SESSION["message-danger"] = "Maaf, kata sandi yang anda masukan salah.";
        $_SESSION["time-message"] = time();
        return false;
      }
    }
  }
}
if (isset($_SESSION["data-user"])) {
  function edit_profile($data)
  {
    global $conn, $idUser;
    $username = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data["username"]))));
    $password = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data["password"]))));
    $password = password_hash($password, PASSWORD_DEFAULT);
    mysqli_query($conn, "UPDATE users SET username='$username', password='$password' WHERE id_user='$idUser'");
    return mysqli_affected_rows($conn);
  }
  function add_user($data)
  {
    global $conn;
    $username = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data["username"]))));
    $email = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data["email"]))));
    $checkEmail = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
    if (mysqli_num_rows($checkEmail) > 0) {
      $_SESSION["message-danger"] = "Maaf, email yang anda masukan sudah terdaftar.";
      $_SESSION["time-message"] = time();
      return false;
    }
    $password = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data["password"]))));
    $password = password_hash($password, PASSWORD_DEFAULT);
    mysqli_query($conn, "INSERT INTO users(username,email,password) VALUES('$username','$email','$password')");
    return mysqli_affected_rows($conn);
  }
  function edit_user($data)
  {
    global $conn;
    $id_user = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data["id-user"]))));
    $username = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data["username"]))));
    $email = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data["email"]))));
    $emailOld = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data["emailOld"]))));
    if ($email != $emailOld) {
      $checkEmail = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
      if (mysqli_num_rows($checkEmail) > 0) {
        $_SESSION["message-danger"] = "Maaf, email yang anda masukan sudah terdaftar.";
        $_SESSION["time-message"] = time();
        return false;
      }
    }
    mysqli_query($conn, "UPDATE users SET username='$username', email='$email', updated_at=CURRENT_TIMESTAMP WHERE id_user='$id_user'");
    return mysqli_affected_rows($conn);
  }
  function delete_user($data)
  {
    global $conn;
    $id_user = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data["id-user"]))));
    mysqli_query($conn, "DELETE FROM users WHERE id_user='$id_user'");
    return mysqli_affected_rows($conn);
  }
 

//kategori topik
  function tambah_kategori($data)
  {
    global $conn;
    $nama_kategori = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data['nama-kategori']))));
   $deskripsi_kategori = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data['deskripsi-kategori']))));
    $checkKode = mysqli_query($conn, "SELECT * FROM kategori_topik WHERE kategori_topik LIKE '%$nama_kategori%'");
    if (mysqli_num_rows($checkKode) > 0) {
      $_SESSION["message-danger"] = "Maaf, nama kategori sudah ada.";
      $_SESSION["time-message"] = time();
      return false;
    }
   
    mysqli_query($conn, "INSERT INTO kategori_topik(nama_kategori,deskripsi_kategori) VALUES('$nama_kategori','$deskripsi_kategori')");
    return mysqli_affected_rows($conn);
  }

  function ubah_kategori($data){
    global $conn;
    $id_kategori = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data['id-kategori']))));
    $nama_kategori = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data['nama-kategori']))));
    $deskripsi_kategori = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data['deskripsi-kategori']))));
  
    if ($kategori_topik != $kategoriOld) {
      $checkKode = mysqli_query($conn, "SELECT * FROM kategori_topik WHERE id_kategori LIKE '%$nama_kategori%'");
      if (mysqli_num_rows($checkKode) > 0) {
        $_SESSION["message-danger"] = "Maaf, kode kategori sudah ada.";
        $_SESSION["time-message"] = time();
        return false;
      }
    }
  
     mysqli_query($conn, "UPDATE kategori_topik SET nama_kategori='$nama_kategori', deskripsi_kategori='$deskripsi_kategori' WHERE id_kategori='$id_kategori'");
    return mysqli_affected_rows($conn);
   
  }
  function hapus_kategori($data)
  {
    global $conn;
    $id_kategori = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data['id-kategori']))));
    mysqli_query($conn, "DELETE FROM kategori_topik WHERE id_kategori='$id_kategori'");
    return mysqli_affected_rows($conn);
  }
  
  //skripsi
  function tambah_skripsi($data)
  {
    global $conn;

$nama_mahasiswa = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data['nama_mahasiswa']))));
  $NIM = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data['NIM']))));
  $judul_skripsi = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data['judul_skripsi']))));
  $abstrak_skripsi = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data['abstrak_skripsi']))));
  $Pembimbing = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data['Pembimbing']))));
  $Penguji = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data['Penguji']))));
  $Tahun = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data['Tahun']))));
  $id_kategori = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data['id_kategori']))));


    mysqli_query($conn, "INSERT INTO skripsi ( id_kategori, nama_mahasiswa, NIM, judul_skripsi, abstrak_skripsi, Pembimbing, Penguji, Tahun)
SELECT kategori_topik.id_kategori , 'nama_mahasiswa', 'NIM', 'judul_skripsi', 'abstrak_skripsi', 'Pembimbing', 'Penguji', 'Tahun' FROM kategori_topik WHERE kategori_topik.nama_kategori ='nama_kategori'");


    return mysqli_affected_rows($conn);
  }
  function ubah_skripsi($data)
  {

    global $conn;

    $id_skripsi = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data['id_skripsi']))));
    $nama_mahasiswa = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data['nama_mahasiswa']))));
    $namaOld = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data['namaOld']))));
     $nim = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data['NIM']))));
    $judul_skripsi = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data['judul_skripsi']))));
    $abstrak_skripsi = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data['abstrak_skripsi']))));
    $pembimbing = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data['Pembimbing']))));
    $penguji = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data['Penguji']))));
    $tahun = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data['Tahun']))));
     $kategori_topik = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data['nama_kategori']))));

    if ($nama_mahasiswa != $namaOld) {
      $checkNama = mysqli_query($conn, "SELECT * FROM skripsi WHERE nama_mahasiswa='$nama_mahasiswa'");
      if (mysqli_num_rows($checkNama) > 0) {
        $_SESSION["message-danger"] = "Maaf, nama mahasiswa tersebut sudah ada.";
        $_SESSION["time-message"] = time();
        return false;
      }
    }

    mysqli_query($conn, "UPDATE skripsi SET nama_mahasiswa='$nama_mahasiswa',NIM='$nim' ,judul_skripsi='$judul_skripsi', abstrak_skripsi='$abstrak_skripsi',Pembimbing='$pembimbing', Penguji='$penguji', Tahun='$tahun', kategori_topik='$kategori_topik' , updated_at=CURRENT_TIMESTAMP WHERE id_skripsi='$id_skripsi'");
    return mysqli_affected_rows($conn);

  }
  function hapus_skripsi($data)
  {
    global $conn;
    $id_skripsi = htmlspecialchars(addslashes(trim(mysqli_real_escape_string($conn, $data['id-skripsi']))));
  
    mysqli_query($conn, "DELETE FROM skripsi WHERE id_skripsi='$id_skripsi'");
    return mysqli_affected_rows($conn);
  }
  
}
