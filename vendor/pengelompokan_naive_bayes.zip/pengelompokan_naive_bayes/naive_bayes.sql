-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 10 Bulan Mei 2023 pada 13.09
-- Versi server: 10.4.25-MariaDB
-- Versi PHP: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `naive_bayes`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `bobot_kata`
--

CREATE TABLE `bobot_kata` (
  `id_skripsi` int(11) NOT NULL,
  `id_kata` int(11) DEFAULT NULL,
  `bobot` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `hasil_klasifikasi`
--

CREATE TABLE `hasil_klasifikasi` (
  `id_hasil_klasifikasi` int(11) NOT NULL,
  `id_skripsi` int(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `kategori_topik` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `kata`
--

CREATE TABLE `kata` (
  `id_kata` int(11) NOT NULL,
  `kata` varchar(50) DEFAULT NULL,
  `frekuensi` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori_topik`
--

CREATE TABLE `kategori_topik` (
  `id_kategori` int(11) NOT NULL,
  `nama_kategori` varchar(50) NOT NULL,
  `deskripsi_kategori` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `kategori_topik`
--

INSERT INTO `kategori_topik` (`id_kategori`, `nama_kategori`, `deskripsi_kategori`) VALUES
(12, 'Sistem Informasi', 'afafa,h\\r\\nasdasjv\\r\\nasdadnvadad'),
(20, 'Sistem Pendukung Keputusanrfjen ss', 'brhby');

-- --------------------------------------------------------

--
-- Struktur dari tabel `riwayat_pencarian`
--

CREATE TABLE `riwayat_pencarian` (
  `id_pencarian` int(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `kata_kunci` varchar(255) DEFAULT NULL,
  `tanggal` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `skripsi`
--

CREATE TABLE `skripsi` (
  `id_skripsi` int(11) NOT NULL,
  `id_kategori` int(11) NOT NULL,
  `nama_mahasiswa` varchar(50) NOT NULL,
  `NIM` varchar(50) NOT NULL,
  `judul_skripsi` varchar(255) NOT NULL,
  `abstrak_skripsi` text NOT NULL,
  `Pembimbing` varchar(50) NOT NULL,
  `Penguji` varchar(50) NOT NULL,
  `Tahun` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `skripsi`
--

INSERT INTO `skripsi` (`id_skripsi`, `id_kategori`, `nama_mahasiswa`, `NIM`, `judul_skripsi`, `abstrak_skripsi`, `Pembimbing`, `Penguji`, `Tahun`) VALUES
(7, 12, 'IEN', '23118004', 'dcsdc', 'dcsd', 'DAD', 'dfgd', 2018);

-- --------------------------------------------------------

--
-- Struktur dari tabel `skripsi_preprocessed`
--

CREATE TABLE `skripsi_preprocessed` (
  `id_skripsi_preprocessed` int(11) NOT NULL,
  `id_skripsi` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `abstrak` text NOT NULL,
  `kata_kunci` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `skripsi_preprocessed`
--

INSERT INTO `skripsi_preprocessed` (`id_skripsi_preprocessed`, `id_skripsi`, `judul`, `abstrak`, `kata_kunci`) VALUES
(30, 7, '', '', NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `skripsi_testing`
--

CREATE TABLE `skripsi_testing` (
  `id_skripsi` int(11) NOT NULL,
  `judul` text NOT NULL,
  `abstrak` text NOT NULL,
  `kategori_topik` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `skripsi_testing`
--

INSERT INTO `skripsi_testing` (`id_skripsi`, `judul`, `abstrak`, `kategori_topik`) VALUES
(1, 'asdad', 'adsad', ''),
(6, 'pengelompokan topik skripsi mahasiswa ilmu komputer  unwira berdasarkan abstrak menggunakan metode  na  ve bayes classifier berbasis website', 'berdasarkan latar belakang yang telah diuraikan  penulis tertarik  r nuntuk melakukan penelitian tentang     pengelompokan topik skripsi  r nmahasiswa ilmu komputer unwira berdasarkan abstrak  r nmenggunakan metode na  ve bayes classifier    yang diharapkan mampu  r nmembantu pegawai dan mahasiswa dalam pengarsipan dan pengelompokan  r nskripsi  sehingga mahasiswa tidak kesulitan dalam mencari rujukan dan  r nreferensi yang terkait dengan penelitiannya ', ''),
(7, '', '', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `skripsi_training`
--

CREATE TABLE `skripsi_training` (
  `id_skripsi` int(11) NOT NULL,
  `judul` text NOT NULL,
  `abstrak` text NOT NULL,
  `kategori_topik` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `skripsi_training`
--

INSERT INTO `skripsi_training` (`id_skripsi`, `judul`, `abstrak`, `kategori_topik`) VALUES
(1, 'asdad', 'adsad', ''),
(6, 'pengelompokan topik skripsi mahasiswa ilmu komputer  unwira berdasarkan abstrak menggunakan metode  na  ve bayes classifier berbasis website', 'berdasarkan latar belakang yang telah diuraikan  penulis tertarik  r nuntuk melakukan penelitian tentang     pengelompokan topik skripsi  r nmahasiswa ilmu komputer unwira berdasarkan abstrak  r nmenggunakan metode na  ve bayes classifier    yang diharapkan mampu  r nmembantu pegawai dan mahasiswa dalam pengarsipan dan pengelompokan  r nskripsi  sehingga mahasiswa tidak kesulitan dalam mencari rujukan dan  r nreferensi yang terkait dengan penelitiannya ', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `id_role` int(11) DEFAULT 2,
  `username` varchar(100) DEFAULT NULL,
  `email` varchar(75) DEFAULT NULL,
  `password` varchar(75) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id_user`, `id_role`, `username`, `email`, `password`, `created_at`, `updated_at`) VALUES
(1, 1, 'admin', 'admin@gmail.com', '$2y$10$//KMATh3ibPoI3nHFp7x/u7vnAbo2WyUgmI4x0CVVrH8ajFhMvbjG', '2023-02-27 20:57:53', '2023-02-27 20:57:53'),
(4, 2, 'arlan', 'arlan@gmail.com', '$2y$10$Mi1A9U80LbxvBT4/Fa7oLeurytiGRgLNio6KyDjeg8RHWb/76FewW', '2023-04-14 00:50:01', '2023-04-14 00:50:01'),
(5, 2, 'epan', 'Evi@gmail.com', '$2y$10$p.5d29uh9YJPUIYnEk8C0uhdtOJ7eAvc5rMhWIeM.HJVn.csYAjpO', '2023-04-21 11:31:23', '2023-04-21 11:31:23');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users_role`
--

CREATE TABLE `users_role` (
  `id_role` int(11) NOT NULL,
  `role` varchar(35) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `users_role`
--

INSERT INTO `users_role` (`id_role`, `role`) VALUES
(1, 'Admin'),
(2, 'Owner');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `bobot_kata`
--
ALTER TABLE `bobot_kata`
  ADD KEY `bobot_kata_ibfk_2` (`id_kata`),
  ADD KEY `id_skripsi` (`id_skripsi`);

--
-- Indeks untuk tabel `hasil_klasifikasi`
--
ALTER TABLE `hasil_klasifikasi`
  ADD PRIMARY KEY (`id_hasil_klasifikasi`),
  ADD KEY `kategori_topik` (`kategori_topik`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_skripsi` (`id_skripsi`);

--
-- Indeks untuk tabel `kata`
--
ALTER TABLE `kata`
  ADD PRIMARY KEY (`id_kata`);

--
-- Indeks untuk tabel `kategori_topik`
--
ALTER TABLE `kategori_topik`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indeks untuk tabel `riwayat_pencarian`
--
ALTER TABLE `riwayat_pencarian`
  ADD PRIMARY KEY (`id_pencarian`),
  ADD KEY `id_user` (`id_user`);

--
-- Indeks untuk tabel `skripsi`
--
ALTER TABLE `skripsi`
  ADD PRIMARY KEY (`id_skripsi`),
  ADD KEY `skripsi_ibfk_1` (`id_kategori`);

--
-- Indeks untuk tabel `skripsi_preprocessed`
--
ALTER TABLE `skripsi_preprocessed`
  ADD PRIMARY KEY (`id_skripsi_preprocessed`),
  ADD UNIQUE KEY `id_skripsi` (`id_skripsi`);

--
-- Indeks untuk tabel `skripsi_testing`
--
ALTER TABLE `skripsi_testing`
  ADD PRIMARY KEY (`id_skripsi`);

--
-- Indeks untuk tabel `skripsi_training`
--
ALTER TABLE `skripsi_training`
  ADD PRIMARY KEY (`id_skripsi`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`),
  ADD KEY `id_role` (`id_role`);

--
-- Indeks untuk tabel `users_role`
--
ALTER TABLE `users_role`
  ADD PRIMARY KEY (`id_role`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `kategori_topik`
--
ALTER TABLE `kategori_topik`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT untuk tabel `skripsi`
--
ALTER TABLE `skripsi`
  MODIFY `id_skripsi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `skripsi_preprocessed`
--
ALTER TABLE `skripsi_preprocessed`
  MODIFY `id_skripsi_preprocessed` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `users_role`
--
ALTER TABLE `users_role`
  MODIFY `id_role` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `bobot_kata`
--
ALTER TABLE `bobot_kata`
  ADD CONSTRAINT `bobot_kata_ibfk_2` FOREIGN KEY (`id_kata`) REFERENCES `kata` (`id_kata`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `bobot_kata_ibfk_3` FOREIGN KEY (`id_skripsi`) REFERENCES `skripsi` (`id_skripsi`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `hasil_klasifikasi`
--
ALTER TABLE `hasil_klasifikasi`
  ADD CONSTRAINT `hasil_klasifikasi_ibfk_2` FOREIGN KEY (`kategori_topik`) REFERENCES `kategori_topik` (`id_kategori`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hasil_klasifikasi_ibfk_3` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hasil_klasifikasi_ibfk_4` FOREIGN KEY (`id_skripsi`) REFERENCES `skripsi` (`id_skripsi`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `riwayat_pencarian`
--
ALTER TABLE `riwayat_pencarian`
  ADD CONSTRAINT `riwayat_pencarian_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `skripsi`
--
ALTER TABLE `skripsi`
  ADD CONSTRAINT `skripsi_ibfk_1` FOREIGN KEY (`id_kategori`) REFERENCES `kategori_topik` (`id_kategori`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `skripsi_preprocessed`
--
ALTER TABLE `skripsi_preprocessed`
  ADD CONSTRAINT `skripsi_preprocessed_ibfk_1` FOREIGN KEY (`id_skripsi`) REFERENCES `skripsi` (`id_skripsi`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`id_role`) REFERENCES `users_role` (`id_role`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
